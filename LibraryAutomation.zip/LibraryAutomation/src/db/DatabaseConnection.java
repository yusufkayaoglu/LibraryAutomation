
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	private static final String URL = "jdbc:postgresql://localhost:5432/librarydb2";
	private static final String USER = "postgres"; // PostgreSQL kullanıcı adı
	private static final String PASSWORD = "989393"; // PostgreSQL şifresi

	private static Connection connection;

	// Private constructor, dışarıdan instance yaratılmasını engeller
	private DatabaseConnection() {
	}

	// Singleton metoduyla her zaman aynı bağlantıyı alıyoruz
	public static Connection getConnection() {
		if (connection == null) {
			try {
				// Bağlantıyı başlat
				connection = DriverManager.getConnection(URL, USER, PASSWORD);
				System.out.println("PostgreSQL veritabanına başarılı bir şekilde bağlandı!");
			} catch (SQLException e) {
				System.err.println("Veritabanı bağlantısında bir hata oluştu: " + e.getMessage());
			}
		}
		return connection;
	}

	// Bağlantıyı test etmek için ana metod
	public static void main(String[] args) {
		// Bağlantıyı test etmek için
		Connection conn = getConnection();
		if (conn != null) {
			try {
				conn.close();
				System.out.println("Bağlantı kapatıldı.");
			} catch (SQLException e) {
				System.err.println("Bağlantı kapatma hatası: " + e.getMessage());
			}
		}
	}
}
