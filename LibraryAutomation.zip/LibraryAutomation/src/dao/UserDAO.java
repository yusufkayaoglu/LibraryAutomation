
package dao;

import model.User;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import db.DatabaseConnection;

public class UserDAO {

	private Connection connection;

	// Constructor'da DatabaseConnection'dan alınan bağlantıyı kullanıyoruz
	public UserDAO() {
		this.connection = DatabaseConnection.getConnection();
	}

	public User authenticate(String username, String password) throws SQLException {
		String query = "SELECT * FROM users WHERE username = ? AND password = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				User user = new User(rs.getString("name"), rs.getString("surname"), rs.getString("username"),
						rs.getString("email"), rs.getString("password"), rs.getString("security_question"),
						rs.getString("answer"));
				user.setId(rs.getInt("id"));// ID’yi burada set ediyoruz
				user.setRole(rs.getString("role"));
				return user;
			}
		}
		return null;
	}

	public boolean existsByUsername(String username) throws SQLException {
		String query = "SELECT COUNT(*) FROM users WHERE username = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) > 0; // Kullanıcı adı varsa true döner
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // Hata durumunda SQLException fırlat
		}
		return false;
	}

	public void deleteUser(int userId) throws SQLException {
		String query = "DELETE FROM users WHERE id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, userId);
			stmt.executeUpdate();
		}
	}

	// Kullanıcı bilgilerini güncelleme
	public void updateUser(User user) throws SQLException {
		String query = "UPDATE users SET name = ?,surname=?, username = ?, email = ?, password = ?, security_question = ?, answer = ? WHERE id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, user.getName());
			stmt.setString(2, user.getSurname());
			stmt.setString(3, user.getUsername());
			stmt.setString(4, user.getEmail());
			stmt.setString(5, user.getPassword());
			stmt.setString(6, user.getSecurityQuestion());
			stmt.setString(7, user.getAnswer());
			stmt.setInt(8, user.getId());

			stmt.executeUpdate();
		}
	}

	public boolean existsByEmail(String email) throws SQLException {
		String query = "SELECT COUNT(*) FROM users WHERE email = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, email);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) > 0; // Email varsa true döner
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // Hata durumunda SQLException fırlat
		}
		return false;
	}

	public User findByUsername(String username) {
		Connection conn = DatabaseConnection.getConnection(); // Bağlantı alınıyor
		String sql = "SELECT name,surname,email,password, security_question, answer FROM users WHERE username = ?";
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				// Kullanıcı bilgilerini dönüyoruz
				return new User(rs.getString("name"), rs.getString("surname"), username, rs.getString("email"),
						rs.getString("password"), rs.getString("security_question"), rs.getString("answer"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null; // Kullanıcı bulunamadı
	}

	public void addUser(User user) throws SQLException {
		String query = "INSERT INTO users (name,surname, username,email,password,security_question, answer) VALUES (?, ?, ?, ?, ?, ?,?)";
		try (PreparedStatement stmt = connection.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
			stmt.setString(1, user.getName());
			stmt.setString(2, user.getSurname());
			stmt.setString(3, user.getUsername());
			stmt.setString(4, user.getEmail());
			stmt.setString(5, user.getPassword());
			stmt.setString(6, user.getSecurityQuestion());
			stmt.setString(7, user.getAnswer());
			stmt.executeUpdate();

			// Otomatik olarak atanan ID'yi almak için
			ResultSet generatedKeys = stmt.getGeneratedKeys();
			if (generatedKeys.next()) {
				// Yeni ID'yi User objesine set ediyoruz
				user.setId(generatedKeys.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // Hata durumunda SQLException fırlat
		}
	}

}
