
package dao;

import model.Issue;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class IssueDAO {
	private Connection connection;

	public IssueDAO(Connection connection) {
		this.connection = connection;
	}

	// Sadece issue tablosuna veri ekle
	public boolean saveIssue(Issue issue) throws SQLException {
		String query = "INSERT INTO issue (book_id, student_id, date_of_issue) VALUES (?, ?, ?)";

		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, issue.getBookId()); // book_id
			stmt.setInt(2, issue.getStudentId()); // student_id
			stmt.setDate(3, new java.sql.Date(issue.getIssueDate().getTime())); // date_of_issue
			stmt.executeUpdate();
			return true;
		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new SQLException("Database error: " + ex.getMessage());
		}
	}

	// Issue tablosundan veri sil (issue ID ile)
	public void deleteIssue(int issueId) throws SQLException {
		String query = "DELETE FROM issue WHERE id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, issueId);
			stmt.executeUpdate();
		}
	}

	// Öğrenci ID ve Kitap ID'ye göre issue kaydını sil
	public void deleteIssueByStudentIdAndBookId(int studentId, int bookId) throws SQLException {
		String query = "DELETE FROM issue WHERE student_id = ? AND book_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, studentId);
			stmt.setInt(2, bookId);
			stmt.executeUpdate();
		}
	}

	// Tüm issued kitapları getir (VIEW kullanılarak)
	public List<Issue> getAllIssuedBooks() throws SQLException {
		String query = "SELECT * FROM issued_books_details";
		List<Issue> issuedBooks = new ArrayList<>();

		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {

			while (rs.next()) {
				Issue issue = new Issue(rs.getInt("book_id"), rs.getString("book_name"), // Kitap ismi
						rs.getString("book_edition"), // Kitap sürümü
						rs.getString("book_publisher"), // Yayıncı
						rs.getDouble("book_price"), // Fiyat
						rs.getInt("book_page"), // Sayfa sayısı
						rs.getInt("student_id"), rs.getString("student_name"), // Öğrenci adı
						rs.getString("student_surname"), // Öğrenci soyadı
						rs.getString("student_father"), // Baba adı
						rs.getString("student_course"), // Kurs
						rs.getString("student_branch"), // Bölüm
						rs.getInt("student_year"), // Yıl
						rs.getInt("student_sem"), // Dönem
						rs.getDate("date_of_issue") // Ödünç alma tarihi
				);
				issuedBooks.add(issue);
			}
		}
		return issuedBooks;
	}

	public Issue getIssuedBookByStudentId(int studentId) throws SQLException {
		// View'den veriyi alacak sorgu
		String query = "SELECT * FROM issued_books_details WHERE student_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, studentId);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return new Issue(rs.getInt("book_id"), rs.getString("book_name"), // Kitap ismi
							rs.getString("book_edition"), // Kitap sürümü
							rs.getString("book_publisher"), // Yayıncı
							rs.getDouble("book_price"), // Fiyat
							rs.getInt("book_page"), // Sayfa sayısı
							rs.getInt("student_id"), rs.getString("student_name"), // Öğrenci adı
							rs.getString("student_surname"), // Öğrenci soyadı
							rs.getString("student_father"), // Baba adı
							rs.getString("student_course"), // Kurs
							rs.getString("student_branch"), // Bölüm
							rs.getInt("student_year"), // Yıl
							rs.getInt("student_sem"), // Dönem
							rs.getDate("date_of_issue") // Ödünç alma tarihi
					);
				}
			}
		}
		return null;
	}

	// Issue ID'nin mevcut olup olmadığını kontrol et
	public boolean isIssueIdExists(int issueId) throws SQLException {
		String query = "SELECT COUNT(*) FROM issue WHERE id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, issueId);
			try (ResultSet rs = stmt.executeQuery()) {
				return rs.next() && rs.getInt(1) > 0;
			}
		}
	}
}
