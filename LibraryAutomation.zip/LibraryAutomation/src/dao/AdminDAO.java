package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import db.DatabaseConnection;
import model.User;

public class AdminDAO {
	private Connection connection;

	public AdminDAO() {
		this.connection = DatabaseConnection.getConnection();
	}

	// Sadece "user" rolüne sahip kullanıcıları getir
	public List<User> getAllUsers() throws SQLException {
		List<User> userList = new ArrayList<>();
		String query = "SELECT * FROM users WHERE role = 'user'";

		try (PreparedStatement statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery()) {

			while (resultSet.next()) {
				User user = new User(resultSet.getString("name"), resultSet.getString("surname"),
						resultSet.getString("username"), resultSet.getString("email"), resultSet.getString("password"),
						resultSet.getString("security_question"), resultSet.getString("answer"));
				user.setId(resultSet.getInt("id"));
				user.setRole(resultSet.getString("role"));
				userList.add(user);
			}
		}

		return userList;
	}

	// Belirli bir kullanıcıyı username ile getir
	public User getUserByUsername(String username) throws SQLException {
		String query = "SELECT * FROM users WHERE username = ? AND role = 'user'";

		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setString(1, username);

			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					User user = new User(resultSet.getString("name"), resultSet.getString("surname"),
							resultSet.getString("username"), resultSet.getString("email"),
							resultSet.getString("password"), resultSet.getString("security_uestion"),
							resultSet.getString("answer"));
					user.setId(resultSet.getInt("id"));
					user.setRole(resultSet.getString("role"));
					return user;
				}
			}
		}

		return null;
	}

	// Kullanıcı bilgilerini güncelle
	public void updateUser(User user) throws SQLException {
		// Güncelleme sorgusu
		String query = "UPDATE users SET name = ?,surname=?,username=?, email = ?, password = ?, security_question = ?, answer = ? WHERE id = ? AND role = 'user'";

		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setString(1, user.getName());
			statement.setString(2, user.getSurname());
			statement.setString(3, user.getUsername());
			statement.setString(4, user.getEmail());
			statement.setString(5, user.getPassword());
			statement.setString(6, user.getSecurityQuestion());
			statement.setString(7, user.getAnswer());
			statement.setInt(8, user.getId());

			statement.executeUpdate();
		}
	}

	public void deleteUser(int userId) throws SQLException {
		String query = "DELETE FROM users WHERE id = ? AND role = 'user'"; // Yalnızca 'user' rolündeki kullanıcıları
																			// sil
		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, userId);
			statement.executeUpdate();
		}
	}

	public User getUserById(int userId) throws SQLException {
		String query = "SELECT * FROM users WHERE id = ?";
		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, userId);
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					User user = new User(resultSet.getString("name"), resultSet.getString("surname"),
							resultSet.getString("username"), resultSet.getString("email"),
							resultSet.getString("password"), resultSet.getString("security_question"),
							resultSet.getString("answer"));
					user.setId(resultSet.getInt("id"));
					user.setRole(resultSet.getString("role"));
					return user;
				}
			}
		}
		return null;
	}

}
