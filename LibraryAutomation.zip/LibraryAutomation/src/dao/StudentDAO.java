package dao;

import model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
	private Connection connection;

	public StudentDAO(Connection connection) {
		this.connection = connection;
	}

	// Tüm öğrencileri getir
	public List<Student> getAllStudents() throws SQLException {
		String query = "SELECT * FROM students";
		List<Student> students = new ArrayList<>();
		try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
			while (rs.next()) {
				students.add(new Student(rs.getInt("student_id"), rs.getString("student_name"),
						rs.getString("student_surname"), rs.getString("student_father"), rs.getString("student_course"),
						rs.getString("student_branch"), rs.getInt("student_year"), rs.getInt("student_sem")));
			}
		}
		return students;
	}

	// Yeni öğrenci ekle
	public void addStudent(Student student) throws SQLException {
		String query = "INSERT INTO students (student_id, student_name,student_surname,student_father, student_course, student_branch, student_year, student_sem) VALUES (?, ?, ?, ?, ?, ?, ?,?)";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, student.getStudent_Id());
			stmt.setString(2, student.getStudent_Name());
			stmt.setString(3, student.getStudent_Surname());
			stmt.setString(4, student.getStudent_fatherName());
			stmt.setString(5, student.getStudent_Course());
			stmt.setString(6, student.getStudent_Branch());
			stmt.setInt(7, student.getStudent_Year());
			stmt.setInt(8, student.getStudent_Semester());
			stmt.executeUpdate();
		}
	}

	// Öğrenci ID'sinin var olup olmadığını kontrol et
	public boolean isIdExists(int id) throws SQLException {
		String query = "SELECT COUNT(*) FROM students WHERE student_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) > 0;
			}
		}
		return false;
	}

	// ID'ye göre öğrenci getir
	public Student getStudentById(int id) throws SQLException {
		String query = "SELECT * FROM students WHERE student_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return new Student(rs.getInt("student_id"), rs.getString("student_name"),
							rs.getString("student_surname"), rs.getString("student_father"),
							rs.getString("student_course"), rs.getString("student_branch"), rs.getInt("student_year"),
							rs.getInt("student_sem"));
				}
			}
		}
		return null; // Öğrenci bulunamazsa null döner
	}

	public void deleteStudent(int id) throws SQLException {
		String query = "DELETE FROM students WHERE student_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, id);
			stmt.executeUpdate();
		}
	}

	// Öğrenci güncelleme metodu
	public void updateStudent(Student student) throws SQLException {
		String query = "UPDATE students SET student_name = ?,student_surname=?, student_father = ?, student_course = ?, student_branch = ?, student_year = ?, student_sem = ? WHERE student_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, student.getStudent_Name());
			stmt.setString(2, student.getStudent_Surname());
			stmt.setString(3, student.getStudent_fatherName());
			stmt.setString(4, student.getStudent_Course());
			stmt.setString(5, student.getStudent_Branch());
			stmt.setInt(6, student.getStudent_Year());
			stmt.setInt(7, student.getStudent_Semester());
			stmt.setInt(8, student.getStudent_Id());

			stmt.executeUpdate();
		}
	}

}
