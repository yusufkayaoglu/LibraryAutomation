package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import db.DatabaseConnection;
import model.Book;
import model.Issue;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {
	private Connection connection;

	public BookDAO(Connection connection) {
		this.connection = connection;
	}

	// Tüm kitapları getir
	public List<Book> getAllBooks() throws SQLException {
		String query = "SELECT * FROM books";
		List<Book> books = new ArrayList<>();
		try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
			while (rs.next()) {
				// rs.getInt, rs.getString, rs.getBigDecimal kullanarak kitapları alıyoruz
				books.add(new Book(rs.getInt("book_id"), // book_Name
						rs.getString("book_name"), // book_Edition
						rs.getString("book_edition"), // book_Publisher
						rs.getString("book_publisher"), // book_Price (BigDecimal kullanarak fiyatı alıyoruz)
						rs.getDouble("book_price"), rs.getInt("book_page")
				// book_Page
				));
			}
		}
		return books;
	}

	// Kitap ekle
	public void addBook(Book book) throws SQLException {
		String query = "INSERT INTO books (book_id,book_name,book_edition,book_publisher, book_price, book_page) VALUES (?, ?, ?, ?, ?,?)";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, book.getBook_Id());
			stmt.setString(2, book.getBook_Name());
			stmt.setString(3, book.getBook_Edition());
			stmt.setString(4, book.getBook_Publisher());
			stmt.setDouble(5, book.getBook_Price()); // Fiyatı BigDecimal olarak ekliyoruz
			stmt.setInt(6, book.getBook_Page());
			stmt.executeUpdate();
		}
	}

	// Kitap sil
	public void deleteBook(int bookId) throws SQLException {
		String query = "DELETE FROM books WHERE book_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, bookId);
			stmt.executeUpdate();
		}
	}

	public boolean isIdExists(int id) throws SQLException {
		String query = "SELECT COUNT(*) FROM books WHERE book_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0;
				}
			}
		}
		return false;
	}

	public Book getBookById(int id) throws SQLException {
		String query = "SELECT * FROM books WHERE book_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return new Book(rs.getInt("book_id"), rs.getString("book_name"), rs.getString("book_edition"),
							rs.getString("book_publisher"), rs.getDouble("book_price"), rs.getInt("book_page"));
				}
			}
		}
		return null; // Eğer kitap bulunmazsa null döner
	}

	// Kitap güncelleme metodu
	public void updateBook(Book book) throws SQLException {
		String query = "UPDATE books SET book_name = ?, book_edition = ?, book_publisher = ?, book_price = ?, book_page = ? WHERE book_id = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, book.getBook_Name());
			stmt.setString(2, book.getBook_Edition());
			stmt.setString(3, book.getBook_Publisher());
			stmt.setDouble(4, book.getBook_Price());
			stmt.setInt(5, book.getBook_Page());
			stmt.setInt(6, book.getBook_Id()); // Güncellenecek kitabın ID'si

			stmt.executeUpdate();
		}
	}

}
