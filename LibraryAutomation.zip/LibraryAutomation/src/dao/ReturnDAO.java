package dao;

import model.Return;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReturnDAO {
	private Connection connection;

	public ReturnDAO(Connection connection) {
		this.connection = connection;
	}

	public void insertReturnRecord(Return returnRecord) throws SQLException {
		String sql = "INSERT INTO return (student_id, book_id, doi, dor) VALUES (?, ?, ?, ?)";

		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, returnRecord.getStudentId()); // student_id: int
			ps.setInt(2, returnRecord.getBookId()); // book_id: int
			ps.setDate(3, new java.sql.Date(returnRecord.getDateOfIssue().getTime())); // DOI: Date
			ps.setDate(4, new java.sql.Date(returnRecord.getDateOfReturn().getTime())); // DOR: Date

			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Error inserting return record: " + e.getMessage());
			throw e;
		}
	}

}