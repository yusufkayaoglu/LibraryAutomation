package controller;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;
import model.User;
import service.UserService;

public class UserController {
	private UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}

	// Kullanıcı oluşturma işlemi
	public boolean createUser(String name, String surname, String username, String email, String password,
			String securityQuestion, String answer) {
		try {
			userService.register(name, surname, username, email, password, securityQuestion, answer);
			JOptionPane.showMessageDialog(null, "Kullanıcı başarıyla oluşturuldu!", "Bilgi",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		} catch (IllegalArgumentException ex) {
			showErrorDialog(ex.getMessage());
			return false;
		} catch (SQLException ex) {
			showErrorDialog("Veritabanı hatası oluştu: " + ex.getMessage());
			return false;
		} catch (Exception ex) {
			showErrorDialog("Bilinmeyen bir hata oluştu: " + ex.getMessage());
			return false;
		}
	}

	// Kullanıcıyı username ile getirme işlemi
	public User getUserByUsername(String username) {
		try {
			return userService.getUserByUsername(username);
		} catch (SQLException ex) {
			showErrorDialog("Kullanıcı getirilirken bir hata oluştu: " + ex.getMessage());
			return null;
		}
	}

	// Kullanıcı bilgilerini güncelleme işlemi
	public boolean updateUser(User user) {
		try {
			userService.updateUser(user);
			// JOptionPane.showMessageDialog(null, "Kullanıcı bilgileri başarıyla
			// güncellendi!", "Bilgi", JOptionPane.INFORMATION_MESSAGE);
			return true;
		} catch (SQLException ex) {
			showErrorDialog("Kullanıcı güncellenirken bir hata oluştu: " + ex.getMessage());
			return false;
		}
	}

	// Kullanıcı silme işlemi
	public boolean deleteUser(int userId) {
		try {
			userService.deleteUser(userId);
			return true;
		} catch (SQLException ex) {
			showErrorDialog("Kullanıcı silinirken bir hata oluştu: " + ex.getMessage());
			return false;
		}
	}

	// Hata mesajlarını göstermek için yardımcı metod
	private void showErrorDialog(String message) {
		JOptionPane.showMessageDialog(null, message, "Hata", JOptionPane.ERROR_MESSAGE);
	}

}
