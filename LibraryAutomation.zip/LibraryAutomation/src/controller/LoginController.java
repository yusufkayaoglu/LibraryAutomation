package controller;

import java.sql.SQLException;

import model.User;
import service.UserService; // UserService'i import ediyoruz
import view.LoginFrame;

public class LoginController {

	private static LoginController instance; // Singleton instance
	private UserService userService; // UserService referansı
	private LoginFrame loginFrame; // View

	// Private constructor to prevent instantiation
	private LoginController() {
		// UserService'yi başlatıyoruz ve LoginFrame'i bağlıyoruz
		this.userService = new UserService();
		this.loginFrame = new LoginFrame(this); // View'ı Controller ile bağlıyoruz
	}

	// Singleton metodu
	public static LoginController getInstance() {
		if (instance == null) {
			instance = new LoginController();
		}
		return instance;
	}

	// Kullanıcı giriş işlemi
	public boolean login(String username, String password) {
		try {
			User user = userService.login(username, password); // UserService üzerinden giriş
			return user != null; // Eğer kullanıcı varsa giriş başarılı
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false; // Geçersiz giriş
	}

	public LoginFrame getLoginFrame() {
		return loginFrame;
	}

}
