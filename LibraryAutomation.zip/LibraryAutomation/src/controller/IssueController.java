package controller;

import java.sql.Connection;
import javax.swing.JOptionPane;
import model.Issue;
import service.IssueService;

public class IssueController {

	private IssueService issueService;

	public IssueController(Connection connection) {
		this.issueService = new IssueService(connection); // IssueService örneğini oluştur
	}

	public boolean issueBook(Issue issue) {
		try {
			// Servis katmanında kitabı ödünç verme işlemini çağır
			return issueService.issueBook(issue);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Bir hata oluştu: " + ex.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			return false; // Hata oluştuğunda false döndür
		}
	}
}
