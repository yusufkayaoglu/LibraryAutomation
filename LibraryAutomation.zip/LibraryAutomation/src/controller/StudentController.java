package controller;

import model.Student;
import service.StudentService;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

public class StudentController {
	private StudentService studentService;

	// Constructor ile connection veriliyor
	public StudentController(Connection connection) {
		this.studentService = new StudentService(connection);
	}

	// Mevcut öğrencileri getir
	public List<Student> getStudents() throws SQLException {
		return studentService.getStudents();
	}

	// Yeni öğrenci ekleme işlemi
	public void addNewStudent(String id, String name, String surname, String fatherName, String course, String branch,
			String year, String semester) {
		// Student nesnesi oluşturuluyor
		Student newStudent = new Student(Integer.parseInt(id), name, surname, fatherName, course, branch,
				Integer.parseInt(year), Integer.parseInt(semester));

		// StudentService üzerinden yeni öğrenci ekleniyor
		try {
			studentService.addStudent(newStudent);
			// Başarılı mesajı
			JOptionPane.showMessageDialog(null, "Öğrenci başarıyla eklendi!", "Bilgi", JOptionPane.INFORMATION_MESSAGE);
		} catch (SQLException e) {
			// Hata durumunda mesaj göster
			JOptionPane.showMessageDialog(null, "Öğrenci eklenirken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace(); // Hata loglama
		}
	}

	public void updateStudent(String id, String name, String surname, String fName, String course, String branch,
			String year, String semester) {
		try {
			Student updatedStudent = new Student(Integer.parseInt(id), name, surname, fName, course, branch,
					Integer.parseInt(year), Integer.parseInt(semester));

			studentService.updateStudent(updatedStudent);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Geçersiz giriş: " + e.getMessage(), "Hata", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Öğrenci güncellenirken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	public void deleteStudent(int id) {
		try {
			studentService.deleteStudent(id);
			// JOptionPane.showMessageDialog(null, "Öğrenci başarıyla silindi!", "Bilgi",
			// JOptionPane.INFORMATION_MESSAGE);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Öğrenci silinirken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	// Unique öğrenci ID oluştur
	public String generateUniqueStudentId() {
		Random random = new Random();
		int generatedId = random.nextInt(10000) + 1;
		try {
			while (studentService.checkIfIdExists(generatedId)) {
				generatedId = random.nextInt(10000) + 1;
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Hata durumunda hata loglanıyor
		}
		return String.valueOf(generatedId);
	}

	public Student searchStudentById(int id) {
		try {
			return studentService.findStudentById(id);
		} catch (SQLException e) {
			javax.swing.JOptionPane.showMessageDialog(null, "Öğrenci aranırken bir hata oluştu: " + e.getMessage(),
					"Hata", javax.swing.JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
			return null;
		}
	}
}
