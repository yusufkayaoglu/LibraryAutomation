package controller;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import model.User;
import service.AdminService;

public class AdminController {
	private AdminService adminService;

	public AdminController(AdminService adminService) {
		this.adminService = adminService;
	}

	// Tüm kullanıcıları listele
	public List<User> getAllUsers() {
		try {
			return adminService.getAllUsers();
		} catch (SQLException ex) {
			showErrorDialog("Kullanıcılar getirilirken bir hata oluştu: " + ex.getMessage());
			return null;
		}
	}

	// Username ile kullanıcıyı getir
	public User getUserByUsername(String username) {
		try {
			return adminService.getUserByUsername(username);
		} catch (SQLException ex) {
			showErrorDialog("Kullanıcı getirilirken bir hata oluştu: " + ex.getMessage());
			return null;
		}
	}

	public void deleteUser(int userId) throws SQLException {
		adminService.deleteUser(userId); // AdminService üzerinden silme işlemi
	}

	// Kullanıcı bilgilerini güncelle
	public boolean updateUser(User user) {
		try {
			// E-posta doğrulaması (regex ile)
			if (!user.getEmail().matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
				showErrorDialog("Geçersiz e-posta formatı: " + user.getEmail());
				return false;
			}

			adminService.updateUser(user);
			JOptionPane.showMessageDialog(null, "Kullanıcı bilgileri başarıyla güncellendi!", "Bilgi",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		} catch (SQLException ex) {
			showErrorDialog("Kullanıcı güncellenirken bir hata oluştu: " + ex.getMessage());
			return false;
		}
	}

	// Hata mesajlarını göstermek için yardımcı metod
	private void showErrorDialog(String message) {
		JOptionPane.showMessageDialog(null, message, "Hata", JOptionPane.ERROR_MESSAGE);
	}

	public User getUserById(int userId) throws SQLException {
		return adminService.getUserById(userId);
	}

}
