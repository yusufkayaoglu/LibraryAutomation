package controller;

import model.Book;
import service.BookService;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;

public class BookController {
	private BookService bookService;

	// Constructor ile connection veriliyor
	public BookController(Connection connection) {
		this.bookService = new BookService(connection);
	}

	// Mevcut kitapları getir
	public List<Book> getBooks() throws SQLException {
		return bookService.getBooks();
	}

	// Yeni kitap ekleme işlemi
	public void addNewBook(String id, String name, String edition, String publisher, String price, String page) {
		Book newBook = new Book(Integer.parseInt(id), name, edition, publisher, Double.parseDouble(price),
				Integer.parseInt(page));

		try {
			bookService.addBook(newBook);
			JOptionPane.showMessageDialog(null, "Kitap başarıyla eklendi!", "Bilgi", JOptionPane.INFORMATION_MESSAGE);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Kitap eklenirken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	// Benzersiz kitap ID'si oluşturma
	public String generateUniqueBookId() {
		Random random = new Random();
		int generatedId = random.nextInt(10000) + 1;
		try {
			while (bookService.checkIfIdExists(generatedId)) {
				generatedId = random.nextInt(10000) + 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return String.valueOf(generatedId);
	}

	// ID'ye göre kitap arama
	public Book searchBookById(int id) {
		try {
			return bookService.findBookById(id);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Kitap aranırken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
			return null;
		}
	}

	// Kitap güncelleme işlemi
	public void updateBook(String id, String name, String edition, String publisher, String price, String page) {
		try {
			Book updatedBook = new Book(Integer.parseInt(id), name, edition, publisher, Double.parseDouble(price),
					Integer.parseInt(page));

			bookService.updateBook(updatedBook);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Geçersiz giriş: " + e.getMessage(), "Hata", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Kitap güncellenirken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	// Kitap silme işlemi
	public void deleteBook(int id) {
		try {
			bookService.deleteBook(id);
			JOptionPane.showMessageDialog(null, "Kitap başarıyla silindi!", "Bilgi", JOptionPane.INFORMATION_MESSAGE);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Kitap silinirken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
