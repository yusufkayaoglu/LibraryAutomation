package security;

public class PasswordValidator {

	public static boolean isValidPassword(String password) {
		// Şifre en az 8 karakter olmalı
		if (password.length() < 8) {
			return false;
		}

		// Şifrede en az bir küçük harf olmalı
		if (!password.matches(".*[a-z].*")) {
			return false;
		}

		// Şifrede en az bir büyük harf olmalı
		if (!password.matches(".*[A-Z].*")) {
			return false;
		}

		// Şifrede en az bir özel karakter olmalı
		if (!password.matches(".*[^a-zA-Z0-9].*")) {
			return false;
		}

		return true;
	}
}
