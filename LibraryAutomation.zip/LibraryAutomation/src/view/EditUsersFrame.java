package view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.AdminController;
import model.User;
import service.AdminService;

public class EditUsersFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtUsername;
	private JTextField txtEmail;
	private JTextField txtAnswer;
	private JTable table;
	private JComboBox<String> comboBoxSecurityQuestion;
	private DefaultTableModel tableModel;
	private AdminController adminController;
	private int selectedUserId; // Seçilen kullanıcının ID'sini saklayacak
	private JTextField txtSurname;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				EditUsersFrame frame = new EditUsersFrame();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public EditUsersFrame() {
		setTitle("Edit Users");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1018, 621);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// AdminService ve AdminController'i başlatma
		AdminService adminService = new AdminService();
		adminController = new AdminController(adminService);

		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblName.setBounds(10, 10, 100, 30);
		contentPane.add(lblName);

		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblUsername.setBounds(10, 85, 100, 30);
		contentPane.add(lblUsername);

		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEmail.setBounds(10, 125, 100, 30);
		contentPane.add(lblEmail);

		JLabel lblSecurityQuestion = new JLabel("Security Question:");
		lblSecurityQuestion.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSecurityQuestion.setBounds(10, 166, 147, 30);
		contentPane.add(lblSecurityQuestion);

		JLabel lblAnswer = new JLabel("Answer:");
		lblAnswer.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAnswer.setBounds(10, 212, 100, 30);
		contentPane.add(lblAnswer);

		txtName = new JTextField();
		txtName.setBounds(167, 10, 260, 30);
		contentPane.add(txtName);

		txtUsername = new JTextField();
		txtUsername.setBounds(167, 87, 260, 30);
		contentPane.add(txtUsername);

		txtEmail = new JTextField();
		txtEmail.setBounds(167, 128, 260, 30);
		contentPane.add(txtEmail);

		txtAnswer = new JTextField();
		txtAnswer.setBounds(167, 215, 260, 30);
		contentPane.add(txtAnswer);

		comboBoxSecurityQuestion = new JComboBox<>(new String[] { "What is your mother tongue?",
				"What is your nick name?", "Who is your first childhood friend?", "What is your school name?" });
		comboBoxSecurityQuestion.setBounds(167, 168, 260, 30);
		contentPane.add(comboBoxSecurityQuestion);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 255, 984, 319);
		contentPane.add(scrollPane);

		table = new JTable();
		tableModel = new DefaultTableModel(new Object[][] {},
				new String[] { "ID", "Name", "Surname", "Username", "Email", "Security Question", "Answer" }) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Tablonun düzenlenebilirliğini kapat
			}
		};
		table.setModel(tableModel);
		scrollPane.setViewportView(table);

		// Tablodan satır seçildiğinde alanları doldur
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int selectedRow = table.getSelectedRow();
				selectedUserId = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
				txtName.setText(tableModel.getValueAt(selectedRow, 1).toString());
				txtSurname.setText(tableModel.getValueAt(selectedRow, 2).toString());
				txtUsername.setText(tableModel.getValueAt(selectedRow, 3).toString());
				txtEmail.setText(tableModel.getValueAt(selectedRow, 4).toString());
				comboBoxSecurityQuestion.setSelectedItem(tableModel.getValueAt(selectedRow, 5).toString());
				txtAnswer.setText(tableModel.getValueAt(selectedRow, 6).toString());
			}
		});

		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnUpdate.addActionListener(e -> {
			try {
				User existingUser = adminController.getUserById(selectedUserId);

				if (existingUser != null) {
					existingUser.setName(txtName.getText());
					existingUser.setSurname(txtSurname.getText());
					existingUser.setUsername(txtUsername.getText());
					existingUser.setEmail(txtEmail.getText());
					existingUser.setSecurityQuestion(comboBoxSecurityQuestion.getSelectedItem().toString());
					existingUser.setAnswer(txtAnswer.getText());

					adminController.updateUser(existingUser);
					loadUsers();
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		});
		btnUpdate.setBounds(485, 187, 130, 30);
		btnUpdate.setBackground(Color.WHITE);
		btnUpdate.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\update.png"));
		contentPane.add(btnUpdate);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDelete.addActionListener(e -> {
			int confirmation = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this user?",
					"Confirm Deletion", JOptionPane.YES_NO_OPTION);

			if (confirmation == JOptionPane.YES_OPTION) {
				try {
					adminController.deleteUser(selectedUserId);
					loadUsers(); // Tabloyu güncelle
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}
		});
		btnDelete.setBounds(672, 187, 130, 30);
		btnDelete.setBackground(Color.WHITE);
		btnDelete.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\delete.png"));
		contentPane.add(btnDelete);

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}
		});
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBackground(Color.WHITE);
		btnBack.setBounds(864, 187, 130, 30);
		contentPane.add(btnBack);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\management.png"));
		lblNewLabel.setBounds(657, 10, 150, 150);
		contentPane.add(lblNewLabel);

		txtSurname = new JTextField();
		txtSurname.setBounds(167, 50, 260, 30);
		contentPane.add(txtSurname);

		JLabel lblSurname = new JLabel("Surname:");
		lblSurname.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSurname.setBounds(10, 50, 100, 30);
		contentPane.add(lblSurname);

		loadUsers();
	}

	private void loadUsers() {
		tableModel.setRowCount(0);
		List<User> users = adminController.getAllUsers();
		for (User user : users) {
			tableModel.addRow(new Object[] { user.getId(), user.getName(), user.getSurname(), user.getUsername(),
					user.getEmail(), user.getSecurityQuestion(), user.getAnswer() });
		}
	}
}
