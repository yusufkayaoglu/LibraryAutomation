package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import com.toedter.calendar.JDateChooser;

import controller.BookController;
import controller.IssueController;
import controller.StudentController;
import db.DatabaseConnection;
import model.Book;
import model.Issue;
import model.Student;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class IssueFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtBookName;
	private JTextField txtBookEdition;
	private JTextField txtBookPublisher;
	private JTextField txtBookPrice;
	private JTextField txtBookPages;
	private JTextField txtBookID;
	private JTextField txtStudentId;
	private JTextField txtStudentName;
	private JTextField txtFName;
	private JTextField txtStudentCourse;
	private JTextField txtStudentBranch;
	private JTextField txtStudentYear;
	private JTextField txtStudentSemester;
	private BookController bookController;
	private StudentController studentController;
	private IssueController ıssueController;
	private JDateChooser dateChooser;
	private JTextField txtStudentSurname;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IssueFrame frame = new IssueFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public IssueFrame() {
		setTitle("Issue Page");
		Connection connection = DatabaseConnection.getConnection();
		this.bookController = new BookController(connection);
		this.studentController = new StudentController(connection);
		this.ıssueController = new IssueController(connection);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 998, 613);
		contentPane = new JPanel();
		setLocationRelativeTo(null);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();

		panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 255, 255), 3), // Çerçeve rengi ve kalınlığı
				"Book Detail", // Başlık metni
				TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.PLAIN, 20), // Yazı boyutunu ayarla (20
																							// px)
				Color.ORANGE // Başlık metni rengi
		));

		panel.setBounds(20, 27, 454, 417);
		contentPane.add(panel);
		panel.setLayout(null);

		txtBookID = new JTextField();
		txtBookID.setBounds(105, 55, 200, 30);
		panel.add(txtBookID);
		txtBookID.setColumns(10);

		txtBookPages = new JTextField();
		txtBookPages.setBounds(105, 285, 200, 30);
		panel.add(txtBookPages);
		txtBookPages.setColumns(10);

		txtBookPrice = new JTextField();
		txtBookPrice.setBounds(105, 239, 200, 30);
		panel.add(txtBookPrice);
		txtBookPrice.setColumns(10);

		txtBookPublisher = new JTextField();
		txtBookPublisher.setBounds(105, 194, 200, 30);
		panel.add(txtBookPublisher);
		txtBookPublisher.setColumns(10);

		txtBookEdition = new JTextField();
		txtBookEdition.setBounds(105, 144, 200, 30);
		panel.add(txtBookEdition);
		txtBookEdition.setColumns(10);

		txtBookName = new JTextField();
		txtBookName.setBounds(105, 96, 200, 30);
		panel.add(txtBookName);
		txtBookName.setColumns(10);

		JLabel lblNewLabel_2_3 = new JLabel("Pages");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_3.setBounds(10, 285, 87, 30);
		panel.add(lblNewLabel_2_3);

		JLabel lblNewLabel_2_2 = new JLabel("Price");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_2.setBounds(10, 239, 85, 30);
		panel.add(lblNewLabel_2_2);

		JLabel lblNewLabel_2_1 = new JLabel("Publisher");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_1.setBounds(10, 194, 85, 30);
		panel.add(lblNewLabel_2_1);

		JLabel lblEdition = new JLabel("Edition");
		lblEdition.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEdition.setBounds(10, 144, 74, 30);
		panel.add(lblEdition);

		JLabel lblNam = new JLabel("Name");
		lblNam.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNam.setBounds(10, 96, 45, 30);
		panel.add(lblNam);

		JLabel lblNewLabel = new JLabel("Book ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 55, 87, 30);
		panel.add(lblNewLabel);

		JButton btnSearchBook = new JButton("Search");
		btnSearchBook.setFont(new Font("Arial", Font.BOLD, 14));

		btnSearchBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Tüm alanları sıfırla
				txtBookName.setText("");
				txtBookEdition.setText("");
				txtBookPublisher.setText("");
				txtBookPages.setText("");
				txtBookPrice.setText("");

				String idText = txtBookID.getText();
				if (idText.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Lütfen bir ID girin.", "Hata", JOptionPane.ERROR_MESSAGE);
					return;
				}

				try {
					int id = Integer.parseInt(idText);
					Book book = bookController.searchBookById(id); // bookController sınıfını zaten tanımlamışsınız
					if (book != null) {
						txtBookName.setText(book.getBook_Name());
						txtBookEdition.setText(book.getBook_Edition());
						txtBookPublisher.setText(book.getBook_Publisher());
						txtBookPages.setText(String.valueOf(book.getBook_Page()));
						txtBookPrice.setText(String.valueOf(book.getBook_Price()));
					} else {
						JOptionPane.showMessageDialog(null, "Kitap bulunamadı.", "Bilgi",
								JOptionPane.INFORMATION_MESSAGE);
					}
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Geçerli bir sayı girin.", "Hata", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnSearchBook.setBackground(Color.WHITE);
		btnSearchBook.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Search.png"));
		btnSearchBook.setBounds(315, 54, 130, 30);
		panel.add(btnSearchBook);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(
		        new LineBorder(new Color(255, 0, 0), 3), // Çerçeve rengi ve kalınlığı
		        "Student Detail", // Başlık metni
		        TitledBorder.LEADING,
		        TitledBorder.TOP,
		        new Font("Arial", Font.PLAIN, 20), // Yazı boyutunu ayarla (20 px)
		        new Color(255, 215, 0) // Yazı rengi (Altın sarısı)
		));


		panel_1.setBounds(496, 27, 478, 417);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Student ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 29, 108, 30);
		panel_1.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("Name");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(10, 72, 45, 30);
		panel_1.add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("Father Name");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(10, 155, 108, 30);
		panel_1.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_3 = new JLabel("Course");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_3.setBounds(10, 193, 108, 30);
		panel_1.add(lblNewLabel_1_3);

		JLabel lblNewLabel_1_4 = new JLabel("Branch");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_4.setBounds(10, 232, 108, 30);
		panel_1.add(lblNewLabel_1_4);

		JLabel lblNewLabel_1_5 = new JLabel("Year");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_5.setBounds(10, 268, 45, 30);
		panel_1.add(lblNewLabel_1_5);

		JLabel lblNewLabel_1_6 = new JLabel("Semester");
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_6.setBounds(10, 311, 108, 30);
		panel_1.add(lblNewLabel_1_6);

		txtStudentId = new JTextField();
		txtStudentId.setBounds(128, 32, 200, 30);
		panel_1.add(txtStudentId);
		txtStudentId.setColumns(10);

		txtStudentName = new JTextField();
		txtStudentName.setBounds(128, 72, 200, 30);
		panel_1.add(txtStudentName);
		txtStudentName.setColumns(10);

		txtFName = new JTextField();
		txtFName.setBounds(128, 155, 200, 30);
		panel_1.add(txtFName);
		txtFName.setColumns(10);

		txtStudentCourse = new JTextField();
		txtStudentCourse.setBounds(128, 193, 200, 30);
		panel_1.add(txtStudentCourse);
		txtStudentCourse.setColumns(10);

		txtStudentBranch = new JTextField();
		txtStudentBranch.setBounds(128, 232, 200, 30);
		panel_1.add(txtStudentBranch);
		txtStudentBranch.setColumns(10);

		txtStudentYear = new JTextField();
		txtStudentYear.setBounds(128, 268, 200, 30);
		panel_1.add(txtStudentYear);
		txtStudentYear.setColumns(10);

		txtStudentSemester = new JTextField();
		txtStudentSemester.setBounds(128, 311, 200, 30);
		panel_1.add(txtStudentSemester);
		txtStudentSemester.setColumns(10);

		JButton btnSearchStudent = new JButton("Search");
		btnSearchStudent.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnSearchStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Tüm alanları sıfırla
				txtStudentName.setText("");
				txtStudentSurname.setText("");
				txtFName.setText("");
				txtStudentCourse.setText("");
				txtStudentBranch.setText("");
				txtStudentYear.setText("");
				txtStudentSemester.setText("");

				String idText = txtStudentId.getText();
				if (idText.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Lütfen bir ID girin.", "Hata", JOptionPane.ERROR_MESSAGE);
					return;
				}

				try {
					int id = Integer.parseInt(idText);
					Student student = studentController.searchStudentById(id); // studentController sınıfını zaten
																				// tanımlamışsınız
					if (student != null) {
						txtStudentName.setText(student.getStudent_Name());
						txtStudentSurname.setText(student.getStudent_Surname());
						txtFName.setText(student.getStudent_fatherName());
						txtStudentCourse.setText(student.getStudent_Course());
						txtStudentBranch.setText(student.getStudent_Branch());
						txtStudentYear.setText(String.valueOf(student.getStudent_Year()));
						txtStudentSemester.setText(String.valueOf(student.getStudent_Semester()));
					} else {
						JOptionPane.showMessageDialog(null, "Öğrenci bulunamadı.", "Bilgi",
								JOptionPane.INFORMATION_MESSAGE);
					}
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Geçerli bir sayı girin.", "Hata", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnSearchStudent.setBackground(Color.WHITE);
		btnSearchStudent.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Search.png"));
		btnSearchStudent.setBounds(338, 31, 130, 30);
		panel_1.add(btnSearchStudent);

		txtStudentSurname = new JTextField();
		txtStudentSurname.setColumns(10);
		txtStudentSurname.setBounds(128, 112, 200, 30);
		panel_1.add(txtStudentSurname);

		JLabel lblNewLabel_1_1_1 = new JLabel("Surname");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_1.setBounds(10, 112, 76, 30);
		panel_1.add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_2 = new JLabel("Date of Issue");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(506, 463, 130, 30);
		contentPane.add(lblNewLabel_2);

		dateChooser = new JDateChooser();
		dateChooser.setBounds(644, 463, 200, 30);
		contentPane.add(dateChooser);

		JButton btnIssue = new JButton("Issue");
		btnIssue.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnIssue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int bookId = Integer.parseInt(txtBookID.getText());
					String bookName = txtBookName.getText();
					String edition = txtBookEdition.getText();
					String publisher = txtBookPublisher.getText();
					double price = Double.parseDouble(txtBookPrice.getText());
					int pages = Integer.parseInt(txtBookPages.getText());
					int studentId = Integer.parseInt(txtStudentId.getText());
					String studentName = txtStudentName.getText();
					String studentSurname = txtStudentSurname.getText();
					String fatherName = txtFName.getText();
					String course = txtStudentCourse.getText();
					String branch = txtStudentBranch.getText();
					int year = Integer.parseInt(txtStudentYear.getText());
					int semester = Integer.parseInt(txtStudentSemester.getText());

					java.util.Date date = dateChooser.getDate();
					if (date == null) {
						JOptionPane.showMessageDialog(null, "Lütfen bir tarih seçin.", "Hata",
								JOptionPane.ERROR_MESSAGE);
						clearFields();
						return;
					}
					java.sql.Date issueDate = new java.sql.Date(date.getTime());

					Issue issue = new Issue(bookId, bookName, edition, publisher, price, pages, studentId, studentName,
							studentSurname, fatherName, course, branch, year, semester, issueDate);

					Connection connection = DatabaseConnection.getConnection();
					IssueController issueController = new IssueController(connection);

					boolean success = issueController.issueBook(issue);

					if (success) {
						JOptionPane.showMessageDialog(null, "Kitap başarıyla verildi!", "Başarılı",
								JOptionPane.INFORMATION_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null,
								"Kitap verilirken bir hata oluştu veya aynı kitap zaten verilmiş.", "Hata",
								JOptionPane.ERROR_MESSAGE);
					}

					clearFields(); // Başarı veya hata durumunda alanları temizle

				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Geçerli bir sayı girin.", "Hata", JOptionPane.ERROR_MESSAGE);
					clearFields();
				} catch (Exception ex) {
					ex.printStackTrace();
					JOptionPane.showMessageDialog(null, "Bir hata oluştu: " + ex.getMessage(), "Hata",
							JOptionPane.ERROR_MESSAGE);
					clearFields();
				}
			}
		});

		btnIssue.setBackground(Color.WHITE);
		btnIssue.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\magnifier-eye.png"));
		btnIssue.setBounds(679, 503, 130, 30);
		contentPane.add(btnIssue);

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setBackground(Color.WHITE);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				// Yeni pencereyi aç
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}
		});
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBounds(844, 536, 130, 30);
		contentPane.add(btnBack);
	}

	private void clearFields() {
		// Kitap bilgisi alanlarını temizle
		txtBookID.setText("");
		txtBookName.setText("");
		txtBookEdition.setText("");
		txtBookPublisher.setText("");
		txtBookPrice.setText("");
		txtBookPages.setText("");

		// Öğrenci bilgisi alanlarını temizle
		txtStudentId.setText("");
		txtStudentName.setText("");
		txtStudentSurname.setText("");
		txtFName.setText("");
		txtStudentCourse.setText("");
		txtStudentBranch.setText("");
		txtStudentYear.setText("");
		txtStudentSemester.setText("");

		// Tarih seçiciyi temizle
		dateChooser.setDate(null);
	}

}
