package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import model.User;
import model.UserSession;
import service.UserService;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;

import controller.UserController;
import db.DatabaseConnection;
import java.awt.Font;

public class UserInformationFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblStudent_id;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField txtID;
	private JTextField txtName;
	private JTextField txtUserName;
	private JTextField txtEmail;
	private JLabel lblNewLabel;
	private JLabel lblPp;
	private JPanel panel;
	private JButton btnDelete;
	private UserController userController;
	private JTextField txtSurname;
	private JLabel lblNewLabel_1;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserInformationFrame frame = new UserInformationFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UserInformationFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 631, 413);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);

		userController = new UserController(new UserService());

		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 255, 255), 2), // Çerçeve rengini ve kalınlığını
																					// ayarla
				"Profile", // Başlık metni
				TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.BOLD, 16), // Yazı tipini, boyutunu ve
																							// kalınlığını ayarla
				new Color(255, 0, 0)));
		panel.setBounds(20, 20, 587, 345);
		contentPane.add(panel);
		panel.setLayout(null);

		lblPp = new JLabel("");
		lblPp.setBounds(427, 10, 128, 128);
		panel.add(lblPp);
		lblPp.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\user.png"));

		txtEmail = new JTextField();
		txtEmail.setBounds(150, 195, 173, 30);
		panel.add(txtEmail);
		txtEmail.setColumns(10);

		lblNewLabel_3 = new JLabel("Email:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(10, 195, 45, 30);
		panel.add(lblNewLabel_3);

		txtUserName = new JTextField();
		txtUserName.setBounds(150, 155, 173, 30);
		panel.add(txtUserName);
		txtUserName.setColumns(10);

		txtName = new JTextField();
		txtName.setBounds(150, 77, 173, 30);
		panel.add(txtName);
		txtName.setColumns(10);

		txtID = new JTextField();
		txtID.setBounds(150, 37, 173, 30);
		txtID.setEditable(false); // ID alanını düzenlenemez yapalım
		panel.add(txtID);
		txtID.setColumns(10);

		lblNewLabel = new JLabel("Username:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 155, 85, 30);
		panel.add(lblNewLabel);

		lblNewLabel_2 = new JLabel("Name:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(10, 77, 85, 30);
		panel.add(lblNewLabel_2);

		lblStudent_id = new JLabel("User ID:");
		lblStudent_id.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblStudent_id.setBounds(10, 37, 85, 30);
		panel.add(lblStudent_id);

		// Update Butonu
		JButton btnUpdate = new JButton("Update Profile");
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 14));

		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = txtName.getText();
				String surname = txtSurname.getText();
				String username = txtUserName.getText();
				String email = txtEmail.getText();

				User currentUser = UserSession.getCurrentUser();
				if (currentUser != null) {
					currentUser.setName(name);
					currentUser.setSurname(surname);
					currentUser.setUsername(username);
					currentUser.setEmail(email);

					try {
						userController.updateUser(currentUser);
						JOptionPane.showMessageDialog(null, "Profil başarıyla güncellendi!", "Bilgi",
								JOptionPane.INFORMATION_MESSAGE);

						// Kullanıcı bilgilerini yeniden yükle
						loadUserData(); // Burada formu güncellemek için mevcut kullanıcı bilgilerini yeniden
										// dolduruyoruz
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "Profil güncellenirken bir hata oluştu: " + ex.getMessage(),
								"Hata", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});

		btnUpdate.setBackground(Color.WHITE);
		btnUpdate.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\update.png"));
		btnUpdate.setBounds(210, 268, 173, 30);
		btnUpdate.setFocusable(false);
		panel.add(btnUpdate);

		// Delete Butonu
		btnDelete = new JButton("Delete Profile");
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showConfirmDialog(null, "Profilinizi silmek istediğinize emin misiniz?",
						"Silme Onayı", JOptionPane.YES_NO_OPTION);

				if (confirm == JOptionPane.YES_OPTION) {
					User currentUser = UserSession.getCurrentUser();
					if (currentUser != null) {
						try {
							userController.deleteUser(currentUser.getId());
							UserSession.clearCurrentUser();
							JOptionPane.showMessageDialog(null, "Profiliniz silindi!");
							dispose();
						} catch (Exception ex) {
							JOptionPane.showMessageDialog(null, "Profil silinirken bir hata oluştu: " + ex.getMessage(),
									"Hata", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
		});

		btnDelete.setBackground(Color.WHITE);
		btnDelete.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\delete.png"));
		btnDelete.setBounds(10, 268, 173, 30);
		btnDelete.setFocusable(false);
		panel.add(btnDelete);

		// Back Butonu
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setBackground(Color.WHITE);
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBounds(404, 270, 173, 30);
		btnBack.setFocusable(false);
		panel.add(btnBack);

		txtSurname = new JTextField();
		txtSurname.setColumns(10);
		txtSurname.setBounds(150, 117, 173, 30);
		panel.add(txtSurname);

		lblNewLabel_1 = new JLabel("Surname:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 117, 85, 30);
		panel.add(lblNewLabel_1);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}
		});

		// Kullanıcı verilerini yükle
		loadUserData();
	}

	private void loadUserData() {
		User currentUser = UserSession.getCurrentUser();

		if (currentUser != null) {
			txtID.setText(String.valueOf(currentUser.getId()));
			txtName.setText(currentUser.getName());
			txtSurname.setText(currentUser.getSurname());
			txtUserName.setText(currentUser.getUsername());
			txtEmail.setText(currentUser.getEmail());
		} else {
			JOptionPane.showMessageDialog(null, "Oturum açan kullanıcı bilgisi bulunamadı!", "Hata",
					JOptionPane.ERROR_MESSAGE);
		}
	}
}
