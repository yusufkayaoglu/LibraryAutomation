package view;

import controller.StudentController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdateStudentFrame extends JFrame {
	private JTextField txtName, txtSurname, txtFName, txtCourse, txtBranch, txtYear, txtSemester;
	private String studentId;
	private StudentController studentController;
	private ManageRecordsFrame parentFrame; // Ana pencere referansı

	public UpdateStudentFrame(String studentId, String name, String surname, String fName, String course, String branch,
			String year, String semester, StudentController studentController, ManageRecordsFrame parentFrame) {
		this.studentId = studentId;
		this.studentController = studentController;
		this.parentFrame = parentFrame;

		setTitle("Öğrenci Güncelle");
		setSize(600, 500);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new GridLayout(8, 2, 10, 10));

		getContentPane().add(new JLabel("Öğrenci Adı:"));
		txtName = new JTextField(name);
		getContentPane().add(txtName);

		getContentPane().add(new JLabel("Soyadı:"));
		txtSurname = new JTextField(surname);
		getContentPane().add(txtSurname);

		getContentPane().add(new JLabel("Veli Adı:"));
		txtFName = new JTextField(fName);
		getContentPane().add(txtFName);

		getContentPane().add(new JLabel("Kurs:"));
		txtCourse = new JTextField(course);
		getContentPane().add(txtCourse);

		getContentPane().add(new JLabel("Bölüm:"));
		txtBranch = new JTextField(branch);
		getContentPane().add(txtBranch);

		getContentPane().add(new JLabel("Yıl:"));
		txtYear = new JTextField(year);
		getContentPane().add(txtYear);

		getContentPane().add(new JLabel("Dönem:"));
		txtSemester = new JTextField(semester);
		getContentPane().add(txtSemester);

		JButton btnUpdate = new JButton("Güncelle");
		getContentPane().add(btnUpdate);

		JButton btnCancel = new JButton("İptal");
		getContentPane().add(btnCancel);

		// Güncelle butonu için ActionListener
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newName = txtName.getText();
				String newSurname = txtSurname.getText();
				String newFName = txtFName.getText();
				String newCourse = txtCourse.getText();
				String newBranch = txtBranch.getText();
				String newYear = txtYear.getText();
				String newSemester = txtSemester.getText();

				try {
					studentController.updateStudent(studentId, newName, newSurname, newFName, newCourse, newBranch,
							newYear, newSemester);
					JOptionPane.showMessageDialog(null, "Öğrenci başarıyla güncellendi!", "Bilgi",
							JOptionPane.INFORMATION_MESSAGE);

					// Ana pencereyi güncelle
					parentFrame.loadStudentData();
					dispose(); // Bu pencereyi kapat
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Güncelleme sırasında bir hata oluştu: " + ex.getMessage(),
							"Hata", JOptionPane.ERROR_MESSAGE);
					ex.printStackTrace();
				}
			}
		});

		// İptal butonu için ActionListener
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose(); // Pencereyi kapat
			}
		});
	}
}
