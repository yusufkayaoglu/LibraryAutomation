package view;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.awt.Color;
import javax.swing.JProgressBar;
import javax.swing.border.LineBorder;

public class LoadingFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoadingFrame frame = new LoadingFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public LoadingFrame() {
		setTitle("Loading");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 742, 812);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		ImageIcon gazi = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\GaziLogoMin.png");
		ImageIcon book = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\BookGIF.gif");
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(255, 0, 0), 3));
		panel.setBounds(41, 10, 652, 755);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblBookGIF = new JLabel("");
		lblBookGIF.setBounds(76, 393, 500, 352);
		panel.add(lblBookGIF);
		lblBookGIF.setIcon(book);

		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(40, 313, 569, 26);
		panel.add(progressBar);
		progressBar.setStringPainted(true);

		JLabel lblGazi = new JLabel("");
		lblGazi.setBounds(230, 81, 200, 195);
		panel.add(lblGazi);
		lblGazi.setIcon(gazi);

		JLabel lblNewLabel = new JLabel("#Bibliotheca Gazi 1.1\r\n");
		lblNewLabel.setBounds(146, 0, 360, 71);
		panel.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(0, 191, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 36));

		JLabel lblNewLabel_1 = new JLabel("Please wait... ");
		lblNewLabel_1.setBounds(230, 349, 200, 26);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));

		new Thread(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i <= 100; i++) {
					try {
						// ProgressBar'ın değerini arttırıyoruz
						progressBar.setValue(i);
						// Her bir adım arasında beklemek için sleep ekliyoruz
						Thread.sleep(50); // 50 ms bekle
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				// Progress bar tamamlandığında Home sayfasına yönlendiriyoruz
				// Yönlendirmek için yeni bir sayfa (HomePageFrame) oluşturabiliriz
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						// Burada HomePageFrame'inizi gösteriyorsunuz
						HomePageFrame homeFrame = new HomePageFrame();
						homeFrame.setVisible(true);
						// Bu loading frame'i kapatıyoruz
						dispose();
					}
				});
			}
		}).start();
	}
}
