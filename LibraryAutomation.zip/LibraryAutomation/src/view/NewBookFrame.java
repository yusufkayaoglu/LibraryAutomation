package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;

import controller.BookController;
import db.DatabaseConnection;

import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class NewBookFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtBookId;
	private JTextField txtbookName;
	private JTextField txtbookPublisher;
	private JTextField txtbookPrice;
	private JTextField txtbookPage;
	private BookController bookController;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewBookFrame frame = new NewBookFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public NewBookFrame() {
		Connection connection = DatabaseConnection.getConnection();
		this.bookController = new BookController(connection);
		String uniqueBookId = bookController.generateUniqueBookId();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 435, 549);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		setFocusable(true); // JFrame'e odaklanabilirlik ekleyin
		requestFocusInWindow();

		JPanel panel = new JPanel();
		/*
		 * panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 205), 3),
		 * "New Book", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(46, 139,
		 * 87)));
		 */
		TitledBorder titledBorder = new TitledBorder(new LineBorder(new Color(0, 0, 205), 3), "New Book",
				TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.BOLD, 14), // Font ekledik ve
																							// kalınlaştırdık
				new Color(46, 139, 87));
		panel.setBorder(titledBorder);
		panel.setBounds(10, 20, 401, 471);
		contentPane.add(panel);
		panel.setLayout(null);
		JComboBox comboBoxbookEdition = new JComboBox();
		comboBoxbookEdition.setFont(new Font("Arial", Font.BOLD, 14));
		comboBoxbookEdition.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6" }));
		comboBoxbookEdition.setBounds(112, 168, 200, 30);
		panel.add(comboBoxbookEdition);

		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Arial", Font.BOLD, 14));
		btnAdd.setBackground(Color.WHITE);
		btnAdd.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\AddBook Min.png"));
		btnAdd.setBounds(152, 381, 130, 30);
		panel.add(btnAdd);

		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Kullanıcıdan alınan veriler
				// String ıd=txtBookId.getText();
				// Yeni benzersiz kitap ID'si üret
				String ıd = txtBookId.getText();
				String name = txtbookName.getText();
				String edition = (String) comboBoxbookEdition.getSelectedItem();
				String publisher = txtbookPublisher.getText();
				String price = txtbookPrice.getText();
				String page = txtbookPage.getText();
				Connection connection = DatabaseConnection.getConnection();
				// Controller sınıfına yönlendirme
				BookController bookController = new BookController(connection);
				bookController.addNewBook(ıd, name, edition, publisher, price, page);

				// Formu sıfırlama işlemi
				String uniqueBookId = bookController.generateUniqueBookId();
				txtBookId.setText(uniqueBookId);
				txtbookName.setText("");
				comboBoxbookEdition.setSelectedIndex(0);
				txtbookPublisher.setText("");
				txtbookPrice.setText("");
				txtbookPage.setText("");

			}
		});

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Arial", Font.BOLD, 14));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();

				// Yeni pencereyi aç
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}
		});
		btnBack.setBackground(Color.WHITE);
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBounds(261, 431, 130, 30);
		panel.add(btnBack);

		JLabel lblNewLabel = new JLabel("Book ID");
		lblNewLabel.setBounds(10, 64, 87, 30);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 114, 45, 30);
		panel.add(lblName);
		lblName.setFont(new Font("Arial", Font.BOLD, 14));

		txtBookId = new JTextField();
		txtBookId.setBounds(112, 65, 200, 30);
		panel.add(txtBookId);
		txtBookId.setFont(new Font("Arial", Font.BOLD, 14));
		txtBookId.setEditable(false); // Kullanıcı düzenleyemesin
		txtBookId.setText(uniqueBookId);
		txtBookId.setColumns(10);

		txtbookName = new JTextField();
		txtbookName.setBounds(112, 115, 200, 30);
		panel.add(txtbookName);
		txtbookName.setFont(new Font("Arial", Font.BOLD, 14));
		txtbookName.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("Edition");
		lblNewLabel_1_1.setBounds(10, 168, 87, 30);
		panel.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel_1_1_1 = new JLabel("Publisher");
		lblNewLabel_1_1_1.setBounds(10, 226, 86, 30);
		panel.add(lblNewLabel_1_1_1);
		lblNewLabel_1_1_1.setFont(new Font("Arial", Font.BOLD, 14));

		txtbookPublisher = new JTextField();
		txtbookPublisher.setBounds(112, 227, 200, 30);
		panel.add(txtbookPublisher);
		txtbookPublisher.setFont(new Font("Arial", Font.BOLD, 14));
		txtbookPublisher.setColumns(10);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("Price");
		lblNewLabel_1_1_1_1.setBounds(10, 276, 45, 30);
		panel.add(lblNewLabel_1_1_1_1);
		lblNewLabel_1_1_1_1.setFont(new Font("Arial", Font.BOLD, 14));

		txtbookPrice = new JTextField();
		txtbookPrice.setBounds(112, 277, 200, 30);
		panel.add(txtbookPrice);
		txtbookPrice.setFont(new Font("Arial", Font.BOLD, 14));
		txtbookPrice.setColumns(10);

		JLabel lblNewLabel_1_1_1_2 = new JLabel("Page");
		lblNewLabel_1_1_1_2.setBounds(10, 330, 45, 30);
		panel.add(lblNewLabel_1_1_1_2);
		lblNewLabel_1_1_1_2.setFont(new Font("Arial", Font.BOLD, 14));

		txtbookPage = new JTextField();
		txtbookPage.setBounds(112, 331, 200, 30);
		panel.add(txtbookPage);
		txtbookPage.setFont(new Font("Arial", Font.BOLD, 14));
		txtbookPage.setColumns(10);

	}
}
