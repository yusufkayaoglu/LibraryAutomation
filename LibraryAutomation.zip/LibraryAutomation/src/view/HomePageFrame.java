package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.TimerTask;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import controller.LoginController;
import model.User;
import model.UserSession;
import service.ExchangeRateAPI;
import service.WeatherService;

import javax.swing.border.LineBorder;
import java.awt.GridLayout;

public class HomePageFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblDate = new JLabel();
	private JLabel lblTime = new JLabel();
	private JLabel lblExchangeRate = new JLabel("Loading Exchange Rates...");
	private JLabel lblWeatherInfo = new JLabel("Loading Weather Information...");

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePageFrame frame = new HomePageFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public HomePageFrame() {
		setTitle("Home");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 1061, 819);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);

		JMenuItem mnıtmExit = new JMenuItem("Exit");
		mnıtmExit.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Exit.png"));
		mnNewMenu.add(mnıtmExit);
		mnıtmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showConfirmDialog(null, "Uygulamayı kapatmak istediğinize emin misiniz?",
						"Çıkış", JOptionPane.YES_NO_OPTION);
				if (confirm == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});

		JMenuItem mnıtmLogout = new JMenuItem("Logout");
		mnıtmLogout.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Logout.png"));
		mnNewMenu.add(mnıtmLogout);
		mnıtmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showConfirmDialog(null, "Oturumu kapatmak istediğinize emin misiniz?",
						"Çıkış Yap", JOptionPane.YES_NO_OPTION);
				if (confirm == JOptionPane.YES_OPTION) {
					dispose(); // Mevcut pencereyi kapat
					LoginFrame loginFrame = LoginController.getInstance().getLoginFrame(); // Singleton'dan LoginFrame'i
					// alıyoruz
					loginFrame.setVisible(true); // LoginFrame'i görünür yapıyoruz
					dispose(); // Giriş ekranını aç
					loginFrame.setVisible(true);
				}
			}
		});

		JMenu mnNewMenu_1 = new JMenu("User Operations");
		menuBar.add(mnNewMenu_1);

		JMenuItem mnıtmProfile = new JMenuItem("Profile");
		mnıtmProfile.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\About.png"));
		mnNewMenu_1.add(mnıtmProfile);

		JMenu mnNewMenu_2 = new JMenu("Admin Operations");
		menuBar.add(mnNewMenu_2);

		JMenuItem mnıItemEditUsers = new JMenuItem("Edit Users");
		mnıItemEditUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut kullanıcıyı UserSession'dan al
				User currentUser = UserSession.getCurrentUser();

				// Kullanıcı mevcutsa ve rolü adminse işlemi gerçekleştir
				if (currentUser != null && "admin".equalsIgnoreCase(currentUser.getRole())) {
					// Admin yetkisi varsa Edit Users sayfasını aç
					dispose();
					EditUsersFrame editUsersFrame = new EditUsersFrame();
					editUsersFrame.setVisible(true);
				} else {
					// Yetkisi olmayan kullanıcıya uyarı mesajı göster
					JOptionPane.showMessageDialog(null, "Bu işlemi gerçekleştirmek için yetkiniz yok!", "Yetki Hatası",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		mnıItemEditUsers
				.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\admin (1).png"));
		mnNewMenu_2.add(mnıItemEditUsers);
		mnıtmProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				UserInformationFrame userInformationFrame = new UserInformationFrame();
				userInformationFrame.setVisible(true);

			}
		});

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\library.PNG"));
		lblNewLabel_1.setBounds(10, 28, 155, 44);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel = new JLabel("#Welcome");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setForeground(new Color(60, 179, 113));
		lblNewLabel.setBounds(852, 0, 104, 30);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_2 = new JLabel("to");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setBounds(900, 28, 23, 21);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("Library Management System\r\n");
		lblNewLabel_4.setForeground(new Color(60, 179, 113));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_4.setBounds(798, 54, 260, 30);
		contentPane.add(lblNewLabel_4);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new LineBorder(new Color(255, 200, 0), 3), "Operations", TitledBorder.LEADING,
				TitledBorder.TOP, new Font("Tahoma", Font.BOLD, 16), // Font ve boyut ayarı
				Color.GREEN));
		panel.setBounds(310, 94, 722, 323);
		contentPane.add(panel);
		panel.setLayout(null);

		JButton btnManageRecords = new JButton("");
		btnManageRecords.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();
				// Yeni pencereyi aç
				ManageRecordsFrame statisticsFrame = new ManageRecordsFrame();
				statisticsFrame.setVisible(true);

			}
		});
		btnManageRecords.setBackground(Color.WHITE);
		btnManageRecords.setBounds(512, 47, 200, 200);
		panel.add(btnManageRecords);
		btnManageRecords
				.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\check-list.png"));

		JButton btnAddBook = new JButton("");
		btnAddBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();

				// Yeni pencereyi aç
				NewBookFrame newBookFrame = new NewBookFrame();
				newBookFrame.setVisible(true);

			}
		});
		btnAddBook.setBackground(Color.WHITE);
		btnAddBook.setBounds(269, 47, 200, 200);
		panel.add(btnAddBook);
		btnAddBook.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\AddBook.png"));

		JButton btnAddStudent = new JButton("");
		btnAddStudent.setBackground(Color.WHITE);
		btnAddStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();

				// Yeni pencereyi aç
				NewStudentFrame newStudentFrame = new NewStudentFrame();
				newStudentFrame.setVisible(true);
			}
		});
		btnAddStudent.setBounds(10, 47, 200, 200);
		panel.add(btnAddStudent);
		btnAddStudent.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\AddStudent.png"));
		btnAddStudent.setFocusPainted(false);
		btnAddBook.setFocusPainted(false);
		btnManageRecords.setFocusPainted(false);

		JLabel lblNewLabel_5 = new JLabel("New Book");
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_5.setBounds(321, 257, 73, 19);
		panel.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Manage Records");
		lblNewLabel_6.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_6.setBounds(551, 260, 132, 16);
		panel.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("New Student");
		lblNewLabel_7.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_7.setBounds(69, 259, 93, 14);
		panel.add(lblNewLabel_7);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new LineBorder(new Color(60, 179, 113), 3), "Action", TitledBorder.LEADING,
				TitledBorder.TOP, new Font("Tahoma", Font.BOLD, 16), // Font ve boyut ayarı
				Color.ORANGE // Yazı rengi
		));

		panel_1.setBounds(310, 427, 722, 323);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JButton btnIssueBook = new JButton("");
		btnIssueBook.setBackground(Color.WHITE);
		btnIssueBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();

				// Yeni pencereyi aç
				IssueFrame ıssueFrame = new IssueFrame();
				ıssueFrame.setVisible(true);

			}
		});
		btnIssueBook.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\open-book.png"));
		btnIssueBook.setBounds(10, 56, 200, 200);
		panel_1.add(btnIssueBook);
		btnIssueBook.setFocusPainted(false);

		JButton btnReturnBook = new JButton("");
		btnReturnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				// Yeni pencereyi aç
				ReturnFrame returnFrame = new ReturnFrame();
				returnFrame.setVisible(true);
			}
		});
		btnReturnBook.setBackground(Color.WHITE);
		btnReturnBook.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\return (1).png"));
		btnReturnBook.setBounds(262, 56, 200, 200);
		panel_1.add(btnReturnBook);
		btnReturnBook.setFocusPainted(false);

		JButton btnAbout = new JButton("");
		btnAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();
				// Yeni pencereyi aç
				AboutFrame aboutFrame = new AboutFrame();
				aboutFrame.setVisible(true);

			}
		});
		btnAbout.setBackground(Color.WHITE);
		btnAbout.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\person.png"));
		btnAbout.setBounds(512, 56, 200, 200);
		panel_1.add(btnAbout);
		btnAbout.setFocusPainted(false);

		JLabel lblNewLabel_7_1 = new JLabel("Issue Book");
		lblNewLabel_7_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_7_1.setBounds(70, 266, 93, 14);
		panel_1.add(lblNewLabel_7_1);

		JLabel lblNewLabel_7_2 = new JLabel("Return Book");
		lblNewLabel_7_2.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_7_2.setBounds(316, 266, 93, 14);
		panel_1.add(lblNewLabel_7_2);

		JLabel lblNewLabel_7_3_1 = new JLabel("About");
		lblNewLabel_7_3_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_7_3_1.setBounds(577, 266, 93, 14);
		panel_1.add(lblNewLabel_7_3_1);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 255), 3), "Daily Updates",
				TitledBorder.LEADING, TitledBorder.TOP, new Font("Tahoma", Font.BOLD, 16), Color.BLUE));
		panel_2.setBounds(10, 94, 282, 656);
		contentPane.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		lblExchangeRate.setFont(new Font("Verdana", Font.PLAIN, 14));
		panel_2.add(lblExchangeRate);
		lblWeatherInfo.setFont(new Font("Verdana", Font.PLAIN, 14));
		panel_2.add(lblWeatherInfo);
		lblDate.setBounds(232, 28, 155, 40);
		contentPane.add(lblDate);
		lblDate.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\calendar.png"));
		lblDate.setFont(new Font("Monospaced", Font.BOLD, 16));
		lblDate.setForeground(Color.BLUE);
		lblTime.setBounds(397, 28, 155, 40);
		contentPane.add(lblTime);
		lblTime.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\clock.png"));
		lblTime.setFont(new Font("Monospaced", Font.BOLD, 16));
		lblTime.setForeground(Color.RED);

		// İlk yüklemeyi başlat
		initialLoad();

		// Tarih ve saat güncellemesini başlat
		startUpdatingTime();

	}

	private void fetchWeather(String city) {
		try {
			String weatherInfo = WeatherService.getWeather(city);
			// System.out.println("Weather Info: " + weatherInfo);
			lblWeatherInfo.setText("<html><div style='font-family: Verdana; font-size: 14px; color: #000000;'>"
					+ weatherInfo + "</div></html>");
		} catch (Exception e) {
			lblWeatherInfo.setText("Error loading weather data.");
		}
	}

	private void fetchExchangeRates() {
		try {
			String result = ExchangeRateAPI.getExchangeRates();
			// System.out.println("Exchange Rate: " + result);
			lblExchangeRate.setText(result);
		} catch (Exception e) {
			lblExchangeRate.setText("Error loading exchange rates.");
		}
	}

	private void startUpdatingWeatherAndExchangeRates() {
		int updateInterval = 5000; // 5 saniye (5000 milisaniye)

		new javax.swing.Timer(updateInterval, e -> {
			new SwingWorker<Void, Void>() {
				@Override
				protected Void doInBackground() {
					fetchWeather("Ankara");
					fetchExchangeRates();
					return null;
				}
			}.execute();
		}).start();
	}

	private void initialLoad() {
		lblWeatherInfo.setText("Loading Weather Information...");
		lblExchangeRate.setText("Loading Exchange Rates...");

		new SwingWorker<Void, Void>() {
			@Override
			protected Void doInBackground() {
				fetchWeather("Ankara");
				fetchExchangeRates();
				return null;
			}

			@Override
			protected void done() {
				startUpdatingWeatherAndExchangeRates(); // İlk yükleme tamamlandıktan sonra periyodik güncellemeyi
														// başlat
			}
		}.execute();
	}

	private void startUpdatingTime() {

		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");

		SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
		Date now = new Date();
		lblDate.setText(dateFormatter.format(now));
		// Java Timer ile tarih ve saat güncellemeleri
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				SwingUtilities.invokeLater(() -> {
					Date now = new Date();
					lblTime.setText(timeFormatter.format(now));
				});
			}
		}, 0, 1000); // 1 saniyede bir çalışır
	}
}
