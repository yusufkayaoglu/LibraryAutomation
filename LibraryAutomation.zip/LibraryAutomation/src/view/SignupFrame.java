package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;

import controller.LoginController;
import controller.UserController;
import dao.UserDAO;
import service.UserService;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SignupFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtAnswer;
	private JTextField txtEmail;
	private JComboBox comboBoxSecurityQuestion;
	private JTextField txtSurname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignupFrame frame = new SignupFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public SignupFrame() {
		setTitle("Signup");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 655, 539);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		// JFrame'e odaklanmayı sıfırlıyoruz
		this.setFocusable(true);
		this.requestFocusInWindow();

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new TitledBorder(new LineBorder(new Color(128, 128, 128), 3), // Kalınlığı 3
																										// piksel olan
																										// mavi kenarlık
				"New Account", // Başlık metni
				TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.BOLD, 18), // Başlık fontu
				new Color(0, 204, 102) // Başlık rengi (mavi tonları)
		)));
		panel.setBounds(10, 10, 622, 482);
		contentPane.add(panel);
		panel.setLayout(null);
		JButton btnCreate = new JButton("Create");
		btnCreate.setFont(new Font("Arial", Font.BOLD, 14)); // Font ayarı
		btnCreate.setBackground(new Color(76, 175, 80)); // Arka plan rengi (Mavi)
		btnCreate.setForeground(Color.WHITE); // Yazı rengi
		btnCreate.setFocusPainted(false); // Focus rengini kaldırmak
		btnCreate.setBorder(BorderFactory.createEmptyBorder()); // Kenarları kaldır

		// Login Butonuna icon ekle
		ImageIcon createIcon = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Create.png");
		btnCreate.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Create.png"));
		btnCreate.setHorizontalAlignment(JButton.LEFT); // Icon sol tarafta
		btnCreate.setIconTextGap(10); // Icon ile yazı arasındaki mesafe

		// Buton üzerine fare geldiğinde renk değişimi
		btnCreate.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				btnCreate.setBackground(new Color(56, 142, 60)); // Fare ile üzerine gelince renk değişimi
			}

			public void mouseExited(java.awt.event.MouseEvent evt) {
				btnCreate.setBackground(new Color(76, 175, 80)); // Fare çıktığında eski renk
			}
		});

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Arial", Font.BOLD, 14)); // Font ayarı
		btnBack.setBackground(new Color(176, 190, 197)); // Arka plan rengi (Mavi)
		btnBack.setForeground(Color.WHITE); // Yazı rengi
		btnBack.setFocusPainted(false); // Focus rengini kaldırmak
		btnBack.setBorder(BorderFactory.createEmptyBorder()); // Kenarları kaldır

		// Login Butonuna icon ekle
		ImageIcon backIcon = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png");
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setHorizontalAlignment(JButton.LEFT); // Icon sol tarafta
		btnBack.setIconTextGap(10); // Icon ile yazı arasındaki mesafe

		// Buton üzerine fare geldiğinde renk değişimi
		btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				btnBack.setBackground(new Color(121, 134, 157)); // Fare ile üzerine gelince renk değişimi
			}

			public void mouseExited(java.awt.event.MouseEvent evt) {
				btnBack.setBackground(new Color(176, 190, 197)); // Fare çıktığında eski renk
			}
		});
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginFrame loginFrame = LoginController.getInstance().getLoginFrame(); // Singleton'dan LoginFrame'i
																						// alıyoruz
				loginFrame.setVisible(true); // LoginFrame'i görünür yapıyoruz
				dispose();

			}
		});
		btnBack.setBounds(482, 442, 130, 30);
		panel.add(btnBack);

		txtAnswer = new JTextField();
		txtAnswer.setFont(new Font("Arial", Font.BOLD, 14));
		txtAnswer.setBounds(208, 319, 294, 30);
		panel.add(txtAnswer);
		txtAnswer.setColumns(10);

		JLabel lblAnswer = new JLabel("Answer");
		lblAnswer.setFont(new Font("Arial", Font.BOLD, 14));
		lblAnswer.setBounds(43, 318, 100, 30);
		panel.add(lblAnswer);

		JLabel lblSecurityQuestion = new JLabel("Security Question");
		lblSecurityQuestion.setFont(new Font("Arial", Font.BOLD, 14));
		lblSecurityQuestion.setBounds(43, 279, 180, 30);
		panel.add(lblSecurityQuestion);

		comboBoxSecurityQuestion = new JComboBox();
		comboBoxSecurityQuestion.setFont(new Font("Arial", Font.BOLD, 14));
		comboBoxSecurityQuestion.setBounds(208, 279, 294, 30);
		panel.add(comboBoxSecurityQuestion);
		comboBoxSecurityQuestion.setModel(new DefaultComboBoxModel(new String[] { "What is your mother tongue?",
				"What is your nick name?", "Who is your first childhood friend?", "What is your school name?" }));
		comboBoxSecurityQuestion.setToolTipText("");

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Arial", Font.BOLD, 14));
		lblPassword.setBounds(43, 198, 100, 30);
		panel.add(lblPassword);

		txtPassword = new JTextField();
		txtPassword.setFont(new Font("Arial", Font.BOLD, 14));
		txtPassword.setBounds(208, 199, 294, 30);
		panel.add(txtPassword);
		txtPassword.setColumns(10);
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Arial", Font.BOLD, 14));
		txtEmail.setBounds(208, 239, 294, 30);
		panel.add(txtEmail);
		txtEmail.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1.setBounds(43, 239, 100, 30);
		panel.add(lblNewLabel_1);

		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = txtName.getText().trim();
				String surname = txtSurname.getText().trim();
				String username = txtUsername.getText().trim();
				String email = txtEmail.getText().trim();
				String password = txtPassword.getText().trim(); // JPasswordField için
				String securityQuestion = (String) comboBoxSecurityQuestion.getSelectedItem();
				String answer = txtAnswer.getText().trim();

				StringBuilder errorMessage = new StringBuilder();

				// Boş alan kontrolü
				if (name.isEmpty()) {
					errorMessage.append("- İsim alanı boş olamaz.\n");
				}
				if (username.isEmpty()) {
					errorMessage.append("- Kullanıcı adı alanı boş olamaz.\n");
				}
				if (email.isEmpty()) {
					errorMessage.append("- Email alanı boş olamaz.\n");
				}
				if (password.isEmpty()) {
					errorMessage.append("- Şifre alanı boş olamaz.\n");
				}
				if (answer.isEmpty()) {
					errorMessage.append("- Güvenlik sorusu cevabı boş olamaz.\n");
				}

				// Email format kontrolü
				if (!email.isEmpty() && !email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
					errorMessage.append("- Geçersiz email formatı.\n");
				}

				// Şifre güçlülük kontrolü
				if (!password.isEmpty() && (password.length() < 8 || !password.matches(".*[A-Z].*")
						|| !password.matches(".*[a-z].*") || !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*"))) {
					errorMessage.append(
							"- Şifre en az 8 karakter, bir büyük harf, bir küçük harf ve bir özel karakter içermelidir.\n");
				}

				// Eğer hata mesajı varsa kullanıcıya göster
				if (errorMessage.length() > 0) {
					JOptionPane.showMessageDialog(null, errorMessage.toString(), "Hata", JOptionPane.ERROR_MESSAGE);
					return;
				}

				// Controller'a bu verileri ileterek kullanıcıyı oluşturma işlemi başlatıyoruz
				try {
					UserService userService = new UserService();
					UserController userController = new UserController(userService);
					boolean success = userController.createUser(name, surname, username, email, password,
							securityQuestion, answer);

					if (success) {
						JOptionPane.showMessageDialog(null, "Kullanıcı başarıyla oluşturuldu!", "Başarılı",
								JOptionPane.INFORMATION_MESSAGE);
						clearFields();
					} else {
						JOptionPane.showMessageDialog(null, "Kullanıcı oluşturulamadı.", "Hata",
								JOptionPane.ERROR_MESSAGE);
					}

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Bir hata oluştu: " + ex.getMessage(), "Hata",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnCreate.setBounds(297, 377, 130, 30);
		panel.add(btnCreate);

		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Arial", Font.BOLD, 14));
		txtUsername.setBounds(208, 159, 294, 30);
		panel.add(txtUsername);
		txtUsername.setColumns(10);

		txtName = new JTextField();
		txtName.setFont(new Font("Arial", Font.BOLD, 14));
		txtName.setBounds(208, 79, 294, 30);
		panel.add(txtName);
		txtName.setColumns(10);

		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(43, 158, 100, 30);
		panel.add(lblUsername);
		lblUsername.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(43, 78, 100, 30);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));

		txtSurname = new JTextField();
		txtSurname.setFont(new Font("Arial", Font.BOLD, 14));
		txtSurname.setColumns(10);
		txtSurname.setBounds(208, 119, 294, 30);
		panel.add(txtSurname);

		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setFont(new Font("Arial", Font.BOLD, 14));
		lblSurname.setBounds(43, 119, 100, 30);
		panel.add(lblSurname);

	}

	// Alanları temizleyen metod
	private void clearFields() {
		txtName.setText("");
		txtSurname.setText("");
		txtUsername.setText("");
		txtEmail.setText("");
		txtPassword.setText("");
		txtAnswer.setText("");
		comboBoxSecurityQuestion.setSelectedIndex(0);
	}
}
