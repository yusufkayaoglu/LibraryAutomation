package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;

import controller.BookController;
import controller.StudentController;
import db.DatabaseConnection;
import model.Student;

import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class NewStudentFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtStudentId;
	private JTextField txtStudentName;
	private JTextField txtStudentFatherName;
	private JTextField txtStudentBranch;
	private StudentController studentController;
	private JTextField txtStudentSurname;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewStudentFrame frame = new NewStudentFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public NewStudentFrame() {
		Connection connection = DatabaseConnection.getConnection();
		this.studentController = new StudentController(connection);
		String uniqueBookId = studentController.generateUniqueStudentId();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 577);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		setFocusable(true); // JFrame'e odaklanabilirlik ekleyin
		requestFocusInWindow();

		JLabel lblNewLabel = new JLabel("Student ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(47, 62, 95, 30);
		contentPane.add(lblNewLabel);

		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblName.setBounds(47, 109, 65, 30);
		contentPane.add(lblName);

		txtStudentId = new JTextField();
		txtStudentId.setBounds(152, 62, 173, 30);
		txtStudentId.setEditable(false); // Kullanıcı düzenleyemesin
		txtStudentId.setText(uniqueBookId); // Benzersiz ID'yi ata
		contentPane.add(txtStudentId);
		txtStudentId.setColumns(10);

		txtStudentName = new JTextField();
		txtStudentName.setColumns(10);
		txtStudentName.setBounds(152, 109, 173, 30);
		contentPane.add(txtStudentName);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new LineBorder(new Color(255, 200, 0), 3), "New Student", TitledBorder.LEADING,
				TitledBorder.TOP, null, new Color(0, 51, 255)));
		panel.setBounds(24, 30, 391, 500);
		contentPane.add(panel);
		panel.setLayout(null);

		txtStudentFatherName = new JTextField();
		txtStudentFatherName.setBounds(129, 177, 173, 30);
		panel.add(txtStudentFatherName);
		txtStudentFatherName.setColumns(10);

		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFatherName.setBounds(22, 177, 97, 30);
		panel.add(lblFatherName);

		JComboBox comboBoxStudentCourse = new JComboBox();
		comboBoxStudentCourse
				.setModel(new DefaultComboBoxModel(new String[] { "B Tech", "BCA", "BBA", "BSC", "MBA", "" }));
		comboBoxStudentCourse.setBounds(129, 224, 173, 30);
		panel.add(comboBoxStudentCourse);

		JComboBox comboBoxStudentYear = new JComboBox();
		comboBoxStudentYear.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4" }));
		comboBoxStudentYear.setBounds(129, 313, 173, 30);
		panel.add(comboBoxStudentYear);

		JComboBox comboBoxStudentSemester = new JComboBox();
		comboBoxStudentSemester
				.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8" }));
		comboBoxStudentSemester.setBounds(129, 360, 173, 30);
		panel.add(comboBoxStudentSemester);

		JButton btnRegister = new JButton("Register");
		btnRegister.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Kullanıcıdan alınan veriler
				String studentId = txtStudentId.getText(); // Rastgele ID oluşturuluyor
				String studentName = txtStudentName.getText();
				String studentSurname = txtStudentSurname.getText();
				String studentFatherName = txtStudentFatherName.getText();
				String studentCourse = (String) comboBoxStudentCourse.getSelectedItem();
				String studentBranch = txtStudentBranch.getText();
				String studentYear = (String) comboBoxStudentYear.getSelectedItem();
				String studentSemester = (String) comboBoxStudentSemester.getSelectedItem();

				// Student nesnesi oluşturuluyor
				Student newStudent = new Student(Integer.parseInt(studentId), studentName, studentSurname,
						studentFatherName, studentCourse, studentBranch, Integer.parseInt(studentYear),
						Integer.parseInt(studentSemester));

				// Connection alınıyor
				Connection connection = DatabaseConnection.getConnection();
				// Controller sınıfına yönlendirme
				StudentController studentController = new StudentController(connection);

				// Öğrenciyi ekliyoruz
				studentController.addNewStudent(studentId, studentName, studentSurname, studentFatherName,
						studentCourse, studentBranch, studentYear, studentSemester);

				// Formu sıfırlama işlemi
				// Formu sıfırlama işlemi
				String uniqueBookId = studentController.generateUniqueStudentId();
				txtStudentId.setText(uniqueBookId);
				txtStudentName.setText("");
				txtStudentSurname.setText("");
				txtStudentFatherName.setText("");
				txtStudentBranch.setText("");
				comboBoxStudentCourse.setSelectedIndex(0);
				comboBoxStudentYear.setSelectedIndex(0);
				comboBoxStudentSemester.setSelectedIndex(0);

			}
		});
		btnRegister.setBounds(150, 409, 130, 30);
		panel.add(btnRegister);
		btnRegister.setBackground(Color.WHITE);
		btnRegister.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Register.png"));
		btnRegister.setFocusPainted(false);

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				// Yeni pencereyi aç
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}
		});
		btnBack.setBounds(251, 460, 130, 30);
		panel.add(btnBack);
		btnBack.setBackground(Color.WHITE);
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setFocusPainted(false);

		JLabel lblSemester = new JLabel("Semester");
		lblSemester.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSemester.setBounds(22, 360, 97, 30);
		panel.add(lblSemester);

		JLabel lblYear = new JLabel("Year");
		lblYear.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblYear.setBounds(22, 313, 45, 30);
		panel.add(lblYear);

		txtStudentBranch = new JTextField();
		txtStudentBranch.setBounds(129, 272, 173, 30);
		panel.add(txtStudentBranch);
		txtStudentBranch.setColumns(10);

		JLabel lblBranch = new JLabel("Branch");
		lblBranch.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBranch.setBounds(22, 272, 97, 30);
		panel.add(lblBranch);

		JLabel lblCourse = new JLabel("Course");
		lblCourse.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCourse.setBounds(22, 224, 97, 30);
		panel.add(lblCourse);

		txtStudentSurname = new JTextField();
		txtStudentSurname.setColumns(10);
		txtStudentSurname.setBounds(129, 129, 173, 30);
		panel.add(txtStudentSurname);

		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSurname.setBounds(22, 129, 97, 30);
		panel.add(lblSurname);
	}
}
