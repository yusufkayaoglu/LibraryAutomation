package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

public class AboutFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AboutFrame frame = new AboutFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public AboutFrame() {
		setTitle("About Page");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setBounds(100, 100, 1047, 671);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setLocationRelativeTo(null);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				// Yeni pencereyi aç
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}

		});
		btnBack.setBackground(Color.WHITE);
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\Kütüphane otomasyonu İkonlar\\Back.png"));
		btnBack.setFocusPainted(false);
		btnBack.setBounds(917, 588, 106, 37);
		contentPane.add(btnBack);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.BLACK, 3));
		panel.setBounds(10, 10, 1013, 568);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(607, 40, 342, 400);
		panel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\Kütüphane otomasyonu İkonlar\\Uygar_min2.jpg"));

		JLabel lblNewLabel_5 = new JLabel("Contact - yusufkayaogluu@gmail.com");
		lblNewLabel_5.setBounds(10, 445, 396, 24);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setFont(new Font("Comic Sans MS", Font.BOLD, 18));

		JLabel lblNewLabel_6 = new JLabel("Github - https://github.com/yusufkayaoglu");
		lblNewLabel_6.setBounds(10, 520, 396, 24);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setFont(new Font("Comic Sans MS", Font.BOLD, 18));

		JLabel lblNewLabel_1 = new JLabel("Bibliotheca Gazi");
		lblNewLabel_1.setBounds(362, 40, 235, 56);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(new Color(25, 25, 112));
		lblNewLabel_1.setFont(new Font("Serif", Font.BOLD, 32));

		// Version yazısı
		JLabel lblNewLabel_2 = new JLabel("Version - 1.01");
		lblNewLabel_2.setBounds(415, 106, 130, 24);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setForeground(new Color(25, 25, 112));
		lblNewLabel_2.setFont(new Font("SansSerif", Font.BOLD, 18));

		// Copyright yazısı
		JLabel lblNewLabel_3 = new JLabel("Copyright @2024");
		lblNewLabel_3.setBounds(411, 140, 151, 24);
		panel.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.ITALIC, 18));

		JLabel lblYusuf = new JLabel("");
		lblYusuf.setBounds(52, 23, 300, 400);
		panel.add(lblYusuf);
		lblYusuf.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\fotomin.png"));
		

		JLabel lblNewLabel_5_1 = new JLabel("Contact - uygargokhankoca@gmail.com");
		lblNewLabel_5_1.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblNewLabel_5_1.setBounds(603, 450, 367, 24);
		panel.add(lblNewLabel_5_1);

		JLabel lblNewLabel_6_1 = new JLabel("Github - https://github.com/gokhanuygar03");
		lblNewLabel_6_1.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblNewLabel_6_1.setBounds(607, 520, 396, 24);
		panel.add(lblNewLabel_6_1);

	}
}
