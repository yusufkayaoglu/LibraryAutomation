package view;

import controller.BookController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdateBookFrame extends JFrame {
	private JTextField txtName, txtEdition, txtPublisher, txtPrice, txtPage;
	private String bookId;
	private BookController bookController;
	private ManageRecordsFrame parentFrame; // Ana pencere referansı

	public UpdateBookFrame(String bookId, String name, String edition, String publisher, String price, String page,
			BookController bookController, ManageRecordsFrame parentFrame) {
		this.bookId = bookId;
		this.bookController = bookController;
		this.parentFrame = parentFrame;

		setTitle("Kitap Güncelle");
		setSize(400, 300);
		setLocationRelativeTo(null);
		setLayout(new GridLayout(6, 2, 10, 10));

		add(new JLabel("Kitap Adı:"));
		txtName = new JTextField(name);
		add(txtName);

		add(new JLabel("Baskı:"));
		txtEdition = new JTextField(edition);
		add(txtEdition);

		add(new JLabel("Yayınevi:"));
		txtPublisher = new JTextField(publisher);
		add(txtPublisher);

		add(new JLabel("Fiyat:"));
		txtPrice = new JTextField(price);
		add(txtPrice);

		add(new JLabel("Sayfa Sayısı:"));
		txtPage = new JTextField(page);
		add(txtPage);

		JButton btnUpdate = new JButton("Güncelle");
		add(btnUpdate);

		JButton btnCancel = new JButton("İptal");
		add(btnCancel);

		// Güncelle butonu için ActionListener
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newName = txtName.getText();
				String newEdition = txtEdition.getText();
				String newPublisher = txtPublisher.getText();
				String newPrice = txtPrice.getText();
				String newPage = txtPage.getText();

				try {
					bookController.updateBook(bookId, newName, newEdition, newPublisher, newPrice, newPage);
					JOptionPane.showMessageDialog(null, "Kitap başarıyla güncellendi!", "Bilgi",
							JOptionPane.INFORMATION_MESSAGE);

					// Ana pencereyi güncelle
					parentFrame.loadBookData();
					dispose(); // Bu pencereyi kapat
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Güncelleme sırasında bir hata oluştu: " + ex.getMessage(),
							"Hata", JOptionPane.ERROR_MESSAGE);
					ex.printStackTrace();
				}
			}
		});

		// İptal butonu için ActionListener
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose(); // Pencereyi kapat
			}
		});
	}
}
