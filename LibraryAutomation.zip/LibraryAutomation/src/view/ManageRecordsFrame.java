package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import controller.BookController;
import controller.StudentController;
import db.DatabaseConnection;
import model.Book;
import model.Student;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JSlider;

public class ManageRecordsFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable book_Table;
	private JTable student_Table;
	private JScrollPane student_scrollPane;
	private JButton btnStudentDelete;
	private BookController bookController;
	private StudentController studentController;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageRecordsFrame frame = new ManageRecordsFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageRecordsFrame() {
		setTitle("Manage Records");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 907, 678);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane book_scrollPane = new JScrollPane();
		book_scrollPane.setBounds(10, 10, 865, 200);
		contentPane.add(book_scrollPane);

		book_Table = new JTable();
		book_Table.getTableHeader().setReorderingAllowed(false);

		book_scrollPane.setViewportView(book_Table);

		book_Table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "book_id", "book_name", "book_edition", "book_publisher", "book_price", "book_page" }) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Tüm hücreleri değiştirilemez yapar
			}
		});

		Connection conn = DatabaseConnection.getConnection();
		bookController = new BookController(conn);
		loadBookData();

		student_scrollPane = new JScrollPane();
		student_scrollPane.setBounds(10, 319, 865, 200);
		contentPane.add(student_scrollPane);

		student_Table = new JTable();
		student_Table.getTableHeader().setReorderingAllowed(false);

		student_scrollPane.setViewportView(student_Table);

		student_Table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Student_ID", "Name", "Surname", "FName", "Course", "Branch", "Year", "Semester" }) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Tüm hücreleri değiştirilemez yapar
			}
		});

		studentController = new StudentController(conn);
		loadStudentData();

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Arial", Font.BOLD, 14));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mevcut sayfayı kapat
				dispose();

				// Yeni pencereyi aç
				HomePageFrame homePageFrame = new HomePageFrame();
				homePageFrame.setVisible(true);
			}
		});
		btnBack.setBackground(Color.WHITE);
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBounds(10, 589, 130, 30);
		contentPane.add(btnBack);

		JButton btnBookUpdate = new JButton("Update Book");
		btnBookUpdate.setFont(new Font("Arial", Font.BOLD, 14));
		btnBookUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Seçili satırın indeksini al
				int selectedRow = book_Table.getSelectedRow();

				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Lütfen güncellemek için bir kitap seçin!", "Uyarı",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				// Seçili satırdan mevcut verileri al
				String id = book_Table.getValueAt(selectedRow, 0).toString();
				String name = book_Table.getValueAt(selectedRow, 1).toString();
				String edition = book_Table.getValueAt(selectedRow, 2).toString();
				String publisher = book_Table.getValueAt(selectedRow, 3).toString();
				String price = book_Table.getValueAt(selectedRow, 4).toString();
				String page = book_Table.getValueAt(selectedRow, 5).toString();

				// Yeni güncelleme penceresini aç
				UpdateBookFrame updateFrame = new UpdateBookFrame(id, name, edition, publisher, price, page,
						bookController, ManageRecordsFrame.this);
				updateFrame.setVisible(true);
			}
		});

		btnBookUpdate.setBackground(Color.WHITE);
		btnBookUpdate.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\update.png"));
		btnBookUpdate.setBounds(694, 222, 185, 30);
		contentPane.add(btnBookUpdate);

		JButton btnBookDelete = new JButton("Delete Book");
		btnBookDelete.setFont(new Font("Arial", Font.BOLD, 14));
		btnBookDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Seçili satırın indeksini al
				int selectedRow = book_Table.getSelectedRow();

				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Lütfen silmek için bir kitap seçin!", "Uyarı",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				// Seçili satırdan kitap ID'sini al
				String id = book_Table.getValueAt(selectedRow, 0).toString();
				String bookName = book_Table.getValueAt(selectedRow, 1).toString();

				// Kullanıcıya onay sorusu
				int confirm = JOptionPane.showConfirmDialog(null,
						"Kitabı silmek istediğinize emin misiniz?\nKitap Adı: " + bookName, "Silme Onayı",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

				// Kullanıcı "Evet" derse silme işlemini gerçekleştir
				if (confirm == JOptionPane.YES_OPTION) {
					try {
						bookController.deleteBook(Integer.parseInt(id));
						JOptionPane.showMessageDialog(null, "Kitap başarıyla silindi!", "Bilgi",
								JOptionPane.INFORMATION_MESSAGE);

						// Tabloyu yeniden yükle (ana tabloyu güncelle)
						loadBookData();
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "Kitap silinirken bir hata oluştu: " + ex.getMessage(),
								"Hata", JOptionPane.ERROR_MESSAGE);
						ex.printStackTrace();
					}
				}
			}
		});

		btnBookDelete.setBackground(Color.WHITE);
		btnBookDelete.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\delete.png"));
		btnBookDelete.setBounds(499, 222, 185, 30);
		contentPane.add(btnBookDelete);

		JButton btnStudentUpdate = new JButton("Update Student");
		btnStudentUpdate.setFont(new Font("Arial", Font.BOLD, 14));
		btnStudentUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Seçili satırın indeksini al
				int selectedRow = student_Table.getSelectedRow();

				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Lütfen güncellemek için bir öğrenci seçin!", "Uyarı",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				// Seçili satırdan mevcut verileri al
				String id = student_Table.getValueAt(selectedRow, 0).toString();
				String name = student_Table.getValueAt(selectedRow, 1).toString();
				String surname = student_Table.getValueAt(selectedRow, 2).toString();
				String fName = student_Table.getValueAt(selectedRow, 3).toString();
				String course = student_Table.getValueAt(selectedRow, 4).toString();
				String branch = student_Table.getValueAt(selectedRow, 5).toString();
				String year = student_Table.getValueAt(selectedRow, 6).toString();
				String semester = student_Table.getValueAt(selectedRow, 7).toString();
				// Yeni güncelleme penceresini aç
				UpdateStudentFrame updateFrame = new UpdateStudentFrame(id, name, surname, fName, course, branch, year,
						semester, studentController, ManageRecordsFrame.this);
				updateFrame.setVisible(true);
			}
		});

		btnStudentUpdate.setBackground(Color.WHITE);
		btnStudentUpdate.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\update.png"));
		btnStudentUpdate.setBounds(694, 531, 185, 30);
		contentPane.add(btnStudentUpdate);

		btnStudentDelete = new JButton("Delete Student");
		btnStudentDelete.setFont(new Font("Arial", Font.BOLD, 14));
		btnStudentDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Seçili satırın indeksini al
				int selectedRow = student_Table.getSelectedRow();

				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(null, "Lütfen silmek için bir öğrenci seçin!", "Uyarı",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				// Seçili satırdan öğrenci ID'sini ve adını al
				String id = student_Table.getValueAt(selectedRow, 0).toString();
				String studentName = student_Table.getValueAt(selectedRow, 1).toString();

				// Kullanıcıya onay sorusu
				int confirm = JOptionPane.showConfirmDialog(null,
						"Öğrenciyi silmek istediğinize emin misiniz?\nÖğrenci Adı: " + studentName, "Silme Onayı",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

				// Kullanıcı "Evet" derse silme işlemini gerçekleştir
				if (confirm == JOptionPane.YES_OPTION) {
					try {
						studentController.deleteStudent(Integer.parseInt(id));
						JOptionPane.showMessageDialog(null, "Öğrenci başarıyla silindi!", "Bilgi",
								JOptionPane.INFORMATION_MESSAGE);

						// Tabloyu yeniden yükle (ana tabloyu güncelle)
						loadStudentData();
					} catch (NumberFormatException ex) {
						JOptionPane.showMessageDialog(null, "Geçersiz ID formatı: " + ex.getMessage(), "Hata",
								JOptionPane.ERROR_MESSAGE);
						ex.printStackTrace();
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "Öğrenci silinirken bir hata oluştu: " + ex.getMessage(),
								"Hata", JOptionPane.ERROR_MESSAGE);
						ex.printStackTrace();
					}
				}
			}
		});

		btnStudentDelete.setBackground(Color.WHITE);
		btnStudentDelete.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\delete.png"));
		btnStudentDelete.setBounds(499, 531, 185, 30);
		contentPane.add(btnStudentDelete);

	}

	public void loadBookData() {
		try {
			// BookController üzerinden kitap listesini al
			List<Book> bookList = bookController.getBooks();
			DefaultTableModel model = (DefaultTableModel) book_Table.getModel();

			// Mevcut veriyi temizle
			model.setRowCount(0);

			// Yeni verileri tabloya ekle
			for (Book book : bookList) {
				model.addRow(new Object[] { book.getBook_Id(), book.getBook_Name(), book.getBook_Edition(),
						book.getBook_Publisher(), book.getBook_Price(), book.getBook_Page() });
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Tabloyu yüklerken bir hata oluştu: " + e.getMessage(), "Hata",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	public void loadStudentData() {
		try {
			List<Student> studentList = studentController.getStudents();
			DefaultTableModel model = (DefaultTableModel) student_Table.getModel();

			model.setRowCount(0); // Mevcut veriyi temizle

			for (Student student : studentList) {
				model.addRow(new Object[] { student.getStudent_Id(), student.getStudent_Name(),
						student.getStudent_Surname(), student.getStudent_fatherName(), student.getStudent_Course(),
						student.getStudent_Branch(), student.getStudent_Year(), student.getStudent_Semester() });
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Öğrenci verileri yüklenirken bir hata oluştu: " + e.getMessage(),
					"Hata", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

}
