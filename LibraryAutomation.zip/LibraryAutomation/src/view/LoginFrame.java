package view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import controller.LoginController;
import controller.UserController;
import model.User;
import service.UserService;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;

import java.awt.Color;
import javax.swing.BorderFactory;

public class LoginFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private LoginController loginController;
	private UserService userService = new UserService(); // UserService'i başlatıyoruz
	private UserController userController = new UserController(userService); // UserController'ı UserService ile
	private User loggedInUser; // başlatıyoruz

	public LoginFrame(LoginController loginController) {
		setTitle("Login");
		this.loginController = loginController;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 518, 406); // Boyutları daha uygun hale getirdik
		setLocationRelativeTo(null); // Frame'i ekranın ortasına yerleştir

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setFocusable(true); // JFrame'e odaklanabilirlik ekleyin
		requestFocusInWindow();

		JPanel panel = new JPanel();

		// TitledBorder oluşturma
		TitledBorder titledBorder = new TitledBorder(new LineBorder(new Color(0, 0, 255), 3), // Kalınlığı 3 piksel olan
																								// mavi kenarlık
				"Login", // Başlık metni
				TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.BOLD, 18), // Başlık fontu
				new Color(0, 102, 204) // Başlık rengi (mavi tonları)
		);

		panel.setBorder(titledBorder); // Kenarlığı panele ekle
		panel.setBounds(72, 30, 613, 342);
		panel.setLayout(null);
		panel.setBounds(10, 24, 481, 317); // Panel boyutlarını değiştirdik
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblKey = new JLabel("");
		lblKey.setBounds(386, 128, 30, 30);
		panel.add(lblKey);

		ImageIcon key = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Key.png");
		lblKey.setIcon(key);

		JLabel lblLock = new JLabel("");
		lblLock.setBounds(386, 65, 30, 30);
		panel.add(lblLock);
		ImageIcon lock = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Lock.png");
		lblLock.setIcon(lock);

		passwordField = new JPasswordField();
		passwordField.setBounds(159, 128, 215, 30);
		panel.add(passwordField);

		usernameField = new JTextField();
		usernameField.setBounds(159, 65, 215, 30);
		panel.add(usernameField);
		usernameField.setColumns(10);

		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblUsername.setBounds(10, 65, 99, 30);
		panel.add(lblUsername);

		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPassword.setBounds(10, 128, 99, 30);
		panel.add(lblPassword);

		// Login Butonu
		JButton loginButton = new JButton("Login");
		loginButton.setBounds(161, 200, 150, 35); // Buton boyutları ve pozisyonu
		loginButton.setFont(new Font("Arial", Font.BOLD, 14)); // Font ayarı
		loginButton.setBackground(new Color(0, 123, 255)); // Arka plan rengi (Mavi)
		loginButton.setForeground(Color.WHITE); // Yazı rengi
		loginButton.setFocusPainted(false); // Focus rengini kaldırmak
		loginButton.setBorder(BorderFactory.createEmptyBorder()); // Kenarları kaldır

		// Login Butonuna icon ekle
		ImageIcon loginIcon = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Login.png");
		loginButton.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Login.png"));
		loginButton.setHorizontalAlignment(JButton.LEFT); // Icon sol tarafta
		loginButton.setIconTextGap(10); // Icon ile yazı arasındaki mesafe

		// Buton üzerine fare geldiğinde renk değişimi
		loginButton.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				loginButton.setBackground(new Color(0, 102, 204)); // Fare ile üzerine gelince renk değişimi
			}

			public void mouseExited(java.awt.event.MouseEvent evt) {
				loginButton.setBackground(new Color(0, 123, 255)); // Fare çıktığında eski renk
			}
		});

		panel.add(loginButton);

		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = usernameField.getText();
				String password = new String(passwordField.getPassword());
				boolean isSuccess = loginController.login(username, password);
				if (isSuccess) {
					clearFields();
					dispose(); // LoginFrame'i kapat
					LoadingFrame loadingFrame = new LoadingFrame(); // Yeni LoadingFrame penceresi oluştur
					loadingFrame.setVisible(true); // LoadingFrame'i görüntüle
				} else {
					JOptionPane.showMessageDialog(null, "Invalid username or password");
				}
			}
		});

		// Signup Butonu
		JButton btnSignup = new JButton("Signup");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearFields();
				SignupFrame signupFrame = new SignupFrame();
				signupFrame.setVisible(true);
				dispose();
			}
		});
		btnSignup.setBounds(224, 257, 150, 35); // Yeni konum

		// Signup Butonuna icon ekle
		ImageIcon signupIcon = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Signup.png");
		btnSignup.setIcon(signupIcon);
		btnSignup.setHorizontalAlignment(JButton.LEFT); // Icon sol tarafta
		btnSignup.setIconTextGap(10);

		// Signup Butonunun renk ayarları (Yeşil)
		btnSignup.setBackground(new Color(40, 167, 69)); // Arka plan rengi (Yeşil)
		btnSignup.setForeground(Color.WHITE); // Yazı rengi
		btnSignup.setFocusPainted(false); // Focus rengini kaldırmak
		btnSignup.setBorder(BorderFactory.createEmptyBorder()); // Kenarları kaldır

		// Signup Butonuna fare geldiğinde renk değişimi
		btnSignup.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				btnSignup.setBackground(new Color(33, 136, 56)); // Fare ile üzerine gelince renk değişimi
			}

			public void mouseExited(java.awt.event.MouseEvent evt) {
				btnSignup.setBackground(new Color(40, 167, 69)); // Fare çıktığında eski renk
			}
		});

		panel.add(btnSignup);

		// Forgot Password Butonu
		JButton btnForgot = new JButton("Forgot Password");
		btnForgot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearFields();
				ForgotFrame forgotFrame = new ForgotFrame(userController);
				forgotFrame.setVisible(true); // ForgotFrame'i görünür hale getirme
				dispose(); // LoginFrame'i kapatma
			}
		});
		btnForgot.setBounds(321, 201, 150, 35); // Yeni konum

		// Forgot Butonuna icon ekle
		ImageIcon forgotIcon = new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Forgot.png");
		btnForgot.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Forgot Password.png"));
		btnForgot.setHorizontalAlignment(JButton.LEFT); // Icon sol tarafta
		btnForgot.setIconTextGap(10);

		// Forgot Butonunun renk ayarları (Açık gri)
		btnForgot.setBackground(new Color(108, 117, 125)); // Arka plan rengi (Açık gri)
		btnForgot.setForeground(Color.WHITE); // Yazı rengi
		btnForgot.setFocusPainted(false); // Focus rengini kaldırmak
		btnForgot.setBorder(BorderFactory.createEmptyBorder()); // Kenarları kaldır

		// Forgot Butonuna fare geldiğinde renk değişimi
		btnForgot.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				btnForgot.setBackground(new Color(86, 92, 98)); // Fare ile üzerine gelince renk değişimi
			}

			public void mouseExited(java.awt.event.MouseEvent evt) {
				btnForgot.setBackground(new Color(108, 117, 125)); // Fare çıktığında eski renk
			}
		});

		panel.add(btnForgot);
		JButton btnTogglePassword = new JButton();
		btnTogglePassword.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\hide.png"));
		btnTogglePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnTogglePassword.setText(""); // Başlangıçta butonun içi boş olacak
		btnTogglePassword.setBounds(426, 118, 40, 40);

		// Başlangıçta beyaz
		btnTogglePassword.setBackground(Color.WHITE);

		// MouseListener ekleyerek fare hareketlerine tepki vereceğiz
		btnTogglePassword.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseEntered(java.awt.event.MouseEvent evt) {
				// Fare butonun üzerine geldiğinde şifreyi göster
				passwordField.setEchoChar((char) 0);

				// Fare butonun üzerine geldiğinde yeşil yap
				btnTogglePassword.setBackground(Color.GREEN);
			}

			public void mouseExited(java.awt.event.MouseEvent evt) {
				// Fare butondan ayrıldığında şifreyi gizle
				passwordField.setEchoChar('*');

				// Fare butondan ayrıldığında rengi beyaz yap
				btnTogglePassword.setBackground(Color.WHITE);
			}
		});

		panel.add(btnTogglePassword);
		panel.add(btnTogglePassword);

	}

	public void clearFields() {
		usernameField.setText(""); // Kullanıcı adını temizle
		passwordField.setText(""); // Şifreyi temizle
	}
}
