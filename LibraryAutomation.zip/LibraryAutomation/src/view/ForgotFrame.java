package view;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Base64;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;

import controller.LoginController;
import controller.UserController;
import model.User;

import java.awt.Color;
import java.awt.Font;

public class ForgotFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textUsername;
	private JTextField textName;
	private JTextField textSecurityquestion;
	private JTextField textAnswer;
	private JTextField textPassword;
	private UserController userController;
	private JTextField textEmail;
	private JTextField textSurname;

	public ForgotFrame(UserController userController) {
		setTitle("Forgor Password");
		this.userController = userController;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 665, 461);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new LineBorder(Color.CYAN, 3), // Kalın ve renkli kenarlık
				"Forgot Password", TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.BOLD, 18), Color.RED // Başlık
																														// rengi
		));
		panel.setBounds(10, 10, 634, 404);
		contentPane.add(panel);
		panel.setLayout(null);

		// Retrieve Button with Icon
		JButton btnRetrive = new JButton("Retrieve");
		btnRetrive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enteredUsername = textUsername.getText().trim();
				String enteredAnswer = textAnswer.getText().trim();

				if (enteredUsername.isEmpty() || enteredAnswer.isEmpty()) {
					javax.swing.JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Warning",
							javax.swing.JOptionPane.WARNING_MESSAGE);
					return;
				}

				// UserController aracılığıyla kullanıcıyı al
				User user = userController.getUserByUsername(enteredUsername);

				if (user != null) {
					// Kullanıcı bulunursa, güvenlik cevabını kontrol et
					if (user.getAnswer().equals(enteredAnswer)) {
						// Cevap doğruysa, şifreyi alana yerleştir
						textPassword.setText(user.getPassword());
					} else {
						// Cevap yanlışsa uyarı ver
						javax.swing.JOptionPane.showMessageDialog(contentPane, "Incorrect answer to security question.",
								"Error", javax.swing.JOptionPane.ERROR_MESSAGE);
					}
				} else {
					// Kullanıcı bulunamazsa uyarı ver
					javax.swing.JOptionPane.showMessageDialog(contentPane, "User not found.", "Error",
							javax.swing.JOptionPane.ERROR_MESSAGE);
				}

			}
		});

		btnRetrive.setBounds(488, 248, 130, 30);
		panel.add(btnRetrive);
		btnRetrive.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Retrive.png"));
		btnRetrive.setBackground(new Color(76, 175, 80)); // Yeşil
		btnRetrive.setForeground(Color.WHITE);
		btnRetrive.setFocusPainted(false);// Beyaz Yazı
		btnRetrive.setFont(new Font("Arial", Font.BOLD, 14));
		btnRetrive.setBorder(BorderFactory.createRaisedBevelBorder());

		btnRetrive.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mousePressed(java.awt.event.MouseEvent evt) {
				btnRetrive.setBackground(new Color(56, 142, 60)); // Koyu Yeşil
			}

			public void mouseReleased(java.awt.event.MouseEvent evt) {
				btnRetrive.setBackground(new Color(76, 175, 80)); // Yeşil
			}
		});

		// Back Button with Icon
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(488, 364, 130, 30);
		panel.add(btnBack);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginFrame loginFrame = LoginController.getInstance().getLoginFrame(); // Singleton'dan LoginFrame'i
																						// alıyoruz
				loginFrame.setVisible(true); // LoginFrame'i görünür yapıyoruz
				dispose();
			}
		});
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBackground(new Color(176, 190, 197)); // Gri
		btnBack.setForeground(Color.WHITE);// Beyaz Yazı
		btnBack.setFocusPainted(false);
		btnBack.setFont(new Font("Arial", Font.BOLD, 14));
		btnBack.setBorder(BorderFactory.createRaisedBevelBorder());

		btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mousePressed(java.awt.event.MouseEvent evt) {
				btnBack.setBackground(new Color(121, 134, 157)); // Koyu Gri
			}

			public void mouseReleased(java.awt.event.MouseEvent evt) {
				btnBack.setBackground(new Color(176, 190, 197)); // Gri
			}
		});
		textEmail = new JTextField();
		textEmail.setFont(new Font("Arial", Font.BOLD, 14));
		textEmail.setBounds(200, 169, 259, 30);
		panel.add(textEmail);
		textEmail.setColumns(10);

		// Search Button with Icon
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enteredUsername = textUsername.getText().trim();

				if (enteredUsername.isEmpty()) {
					javax.swing.JOptionPane.showMessageDialog(contentPane, "Please enter a username.", "Warning",
							javax.swing.JOptionPane.WARNING_MESSAGE);
					return;
				}

				// UserController aracılığıyla kullanıcıyı al
				User user = userController.getUserByUsername(enteredUsername);

				if (user != null) {
					// Kullanıcı bilgilerini forma yerleştir
					textName.setText(user.getName());
					textSurname.setText(user.getSurname());
					textSecurityquestion.setText(user.getSecurityQuestion());
					textEmail.setText(user.getEmail());

				} else {
					// Kullanıcı bulunamadı
					javax.swing.JOptionPane.showMessageDialog(contentPane, "User not found.", "Error",
							javax.swing.JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		btnSearch.setBounds(488, 51, 130, 30);
		panel.add(btnSearch);
		btnSearch.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Search.png"));
		btnSearch.setFont(new Font("Arial", Font.BOLD, 14));

		btnSearch.setBackground(new Color(0, 123, 255)); // Arka plan rengi (Mavi)
		btnSearch.setForeground(Color.WHITE); // Yazı rengi
		btnSearch.setFocusPainted(false); // Focus rengini kaldırmak
		btnSearch.setBorder(BorderFactory.createEmptyBorder());
		btnSearch.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mousePressed(java.awt.event.MouseEvent evt) {
				btnSearch.setBackground(new Color(25, 118, 210)); // Koyu Mavi
			}

			public void mouseReleased(java.awt.event.MouseEvent evt) {
				btnSearch.setBackground(new Color(33, 150, 243)); // Mavi
			}
		});

		JLabel lblNewLabel_1_1_2 = new JLabel("Your Password");
		lblNewLabel_1_1_2.setBounds(10, 288, 130, 30);
		panel.add(lblNewLabel_1_1_2);
		lblNewLabel_1_1_2.setFont(new Font("Arial", Font.BOLD, 14));

		// Password TextField
		textPassword = new JTextField();
		textPassword.setBounds(200, 289, 259, 30);
		panel.add(textPassword);
		textPassword.setFont(new Font("Arial", Font.BOLD, 14));
		textPassword.setColumns(10);

		// Answer TextField
		textAnswer = new JTextField();
		textAnswer.setBounds(200, 249, 259, 30);
		panel.add(textAnswer);
		textAnswer.setFont(new Font("Arial", Font.BOLD, 14));
		textAnswer.setColumns(10);

		// Security Question TextField
		textSecurityquestion = new JTextField();
		textSecurityquestion.setBounds(200, 209, 259, 30);
		panel.add(textSecurityquestion);
		textSecurityquestion.setFont(new Font("Arial", Font.BOLD, 14));
		textSecurityquestion.setColumns(10);

		// Name TextField
		textName = new JTextField();
		textName.setBounds(200, 91, 259, 30);
		panel.add(textName);
		textName.setFont(new Font("Arial", Font.BOLD, 14));
		textName.setColumns(10);

		// Username TextField
		textUsername = new JTextField();
		textUsername.setBounds(200, 51, 259, 30);
		panel.add(textUsername);
		textUsername.setFont(new Font("Arial", Font.BOLD, 14));
		textUsername.setColumns(10);

		JLabel lblNewLabel_1_1_1 = new JLabel("Answer");
		lblNewLabel_1_1_1.setBounds(10, 248, 100, 30);
		panel.add(lblNewLabel_1_1_1);
		lblNewLabel_1_1_1.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel_1_1 = new JLabel("Your Security Question");
		lblNewLabel_1_1.setBounds(10, 208, 180, 30);
		panel.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel_2 = new JLabel("Email");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_2.setBounds(10, 168, 180, 30);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(10, 91, 100, 30);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(10, 51, 100, 30);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel_1_2 = new JLabel("Surname");
		lblNewLabel_1_2.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(10, 128, 100, 30);
		panel.add(lblNewLabel_1_2);

		textSurname = new JTextField();
		textSurname.setFont(new Font("Arial", Font.BOLD, 14));
		textSurname.setColumns(10);
		textSurname.setBounds(200, 131, 259, 30);
		panel.add(textSurname);
	}
}
