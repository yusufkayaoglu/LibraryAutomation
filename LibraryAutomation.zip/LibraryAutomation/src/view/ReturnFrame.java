package view;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import com.toedter.calendar.JDateChooser;
import dao.IssueDAO;
import db.DatabaseConnection;
import model.Issue;
import model.Return;
import service.ReturnService;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Date;
import java.awt.Font;

public class ReturnFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtStudentId;
	private JTextField txtStudentName;
	private JTextField txtStudentFatherName;
	private JTextField txtStudentCourse;
	private JTextField txtStudentBranch;
	private JTextField txtStudentYear;
	private JTextField txtStudentSemester;
	private JTextField txtBookId;
	private JTextField txtBookName;
	private JTextField txtBookEdition;
	private JTextField txtBookPublisher;
	private JTextField txtBookPrice;
	private JTextField txtBookPages;
	private JTextField txtBookDateOfIssue;
	private JTextField txtStudentSurname;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				ReturnFrame frame = new ReturnFrame();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public ReturnFrame() {
		setTitle("Return Book");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 826, 597);
		contentPane = new JPanel();
		setLocationRelativeTo(null);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// Panel oluşturma
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(
		        new LineBorder(new Color(0, 0, 0), 3), // Çerçeve rengi ve kalınlığı
		        "Return Panel", // Başlık metni
		        TitledBorder.LEADING,
		        TitledBorder.TOP,
		        new Font("Arial", Font.BOLD, 20), // Yazı boyutunu ve kalınlığını ayarla
		        Color.RED // Başlık metni rengi
		));
		panel.setBounds(10, 10, 753, 353);

		contentPane.add(panel);
		panel.setLayout(null);

		// Öğrenci bilgileri
		JLabel lblStudentId = new JLabel("Student ID");
		lblStudentId.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblStudentId.setBounds(10, 22, 101, 30);
		panel.add(lblStudentId);

		txtStudentId = new JTextField();
		txtStudentId.setBounds(120, 22, 180, 30);
		panel.add(txtStudentId);
		txtStudentId.setColumns(10);

		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblName.setBounds(10, 62, 101, 30);
		panel.add(lblName);

		txtStudentName = new JTextField();
		txtStudentName.setBounds(120, 62, 180, 30);
		panel.add(txtStudentName);
		txtStudentName.setColumns(10);

		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFatherName.setBounds(10, 142, 101, 30);
		panel.add(lblFatherName);

		txtStudentFatherName = new JTextField();
		txtStudentFatherName.setBounds(120, 142, 180, 30);
		panel.add(txtStudentFatherName);
		txtStudentFatherName.setColumns(10);

		JLabel lblCourse = new JLabel("Course");
		lblCourse.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCourse.setBounds(10, 182, 101, 30);
		panel.add(lblCourse);

		txtStudentCourse = new JTextField();
		txtStudentCourse.setBounds(120, 182, 180, 30);
		panel.add(txtStudentCourse);
		txtStudentCourse.setColumns(10);

		JLabel lblBranch = new JLabel("Branch");
		lblBranch.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBranch.setBounds(10, 222, 101, 30);
		panel.add(lblBranch);

		txtStudentBranch = new JTextField();
		txtStudentBranch.setBounds(120, 222, 180, 30);
		panel.add(txtStudentBranch);
		txtStudentBranch.setColumns(10);

		JLabel lblYear = new JLabel("Year");
		lblYear.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblYear.setBounds(10, 262, 101, 30);
		panel.add(lblYear);

		txtStudentYear = new JTextField();
		txtStudentYear.setBounds(120, 262, 180, 30);
		panel.add(txtStudentYear);
		txtStudentYear.setColumns(10);

		JLabel lblSemester = new JLabel("Semester");
		lblSemester.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSemester.setBounds(10, 302, 101, 30);
		panel.add(lblSemester);

		txtStudentSemester = new JTextField();
		txtStudentSemester.setBounds(120, 302, 180, 30);
		panel.add(txtStudentSemester);
		txtStudentSemester.setColumns(10);

		// Kitap bilgileri
		JLabel lblBookId = new JLabel("Book ID");
		lblBookId.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBookId.setBounds(440, 22, 80, 30);
		panel.add(lblBookId);

		txtBookId = new JTextField();
		txtBookId.setBounds(539, 22, 180, 30);
		panel.add(txtBookId);
		txtBookId.setColumns(10);

		JLabel lblBookName = new JLabel("Name");
		lblBookName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBookName.setBounds(440, 62, 80, 30);
		panel.add(lblBookName);

		txtBookName = new JTextField();
		txtBookName.setBounds(539, 62, 180, 30);
		panel.add(txtBookName);
		txtBookName.setColumns(10);

		JLabel lblEdition = new JLabel("Edition");
		lblEdition.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEdition.setBounds(440, 106, 80, 30);
		panel.add(lblEdition);

		txtBookEdition = new JTextField();
		txtBookEdition.setBounds(539, 106, 180, 30);
		panel.add(txtBookEdition);
		txtBookEdition.setColumns(10);

		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPublisher.setBounds(440, 156, 80, 30);
		panel.add(lblPublisher);

		txtBookPublisher = new JTextField();
		txtBookPublisher.setBounds(539, 156, 180, 30);
		panel.add(txtBookPublisher);
		txtBookPublisher.setColumns(10);

		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPrice.setBounds(440, 196, 80, 30);
		panel.add(lblPrice);

		txtBookPrice = new JTextField();
		txtBookPrice.setBounds(539, 196, 180, 30);
		panel.add(txtBookPrice);
		txtBookPrice.setColumns(10);

		JLabel lblPages = new JLabel("Pages");
		lblPages.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPages.setBounds(440, 236, 80, 30);
		panel.add(lblPages);

		txtBookPages = new JTextField();
		txtBookPages.setBounds(539, 236, 180, 30);
		panel.add(txtBookPages);
		txtBookPages.setColumns(10);

		JLabel lblDateOfIssue = new JLabel("Date of Issue");
		lblDateOfIssue.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblDateOfIssue.setBounds(440, 276, 105, 30);
		panel.add(lblDateOfIssue);

		txtBookDateOfIssue = new JTextField();
		txtBookDateOfIssue.setBounds(539, 276, 180, 30);
		panel.add(txtBookDateOfIssue);
		txtBookDateOfIssue.setColumns(10);

		// Arama butonu
		JButton btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSearch.setBounds(300, 22, 130, 30);
		btnSearch.setBackground(Color.WHITE);
		btnSearch.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Search.png"));
		btnSearch.addActionListener(e -> searchIssuedBook());
		panel.add(btnSearch);

		txtStudentSurname = new JTextField();
		txtStudentSurname.setColumns(10);
		txtStudentSurname.setBounds(120, 102, 180, 30);
		panel.add(txtStudentSurname);

		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSurname.setBounds(10, 102, 80, 30);
		panel.add(lblSurname);

		// Geri dönüş tarihi seçimi
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(553, 373, 180, 30);
		contentPane.add(dateChooser);

		JLabel lblReturnDate = new JLabel("Return Date");
		lblReturnDate.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblReturnDate.setBounds(437, 373, 106, 30);
		contentPane.add(lblReturnDate);

		// Return işlemi butonu
		JButton btnReturn = new JButton("Return");
		btnReturn.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnReturn.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\return (2).png"));
		btnReturn.setBounds(578, 420, 130, 30);
		btnReturn.setBackground(Color.WHITE);
		btnReturn.addActionListener(e -> processReturn(dateChooser));
		contentPane.add(btnReturn);

		// Geri butonu
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\LibraryAutomation\\images\\Back.png"));
		btnBack.setBounds(682, 520, 115, 30);
		btnBack.setBackground(Color.WHITE);
		btnBack.addActionListener(e -> {
			dispose();
			new HomePageFrame().setVisible(true);
		});
		contentPane.add(btnBack);
	}

	private void searchIssuedBook() {
		try {
			int studentId = Integer.parseInt(txtStudentId.getText());
			IssueDAO issueDAO = new IssueDAO(DatabaseConnection.getConnection());
			Issue issue = issueDAO.getIssuedBookByStudentId(studentId);

			if (issue != null) {
				txtBookId.setText(String.valueOf(issue.getBookId()));
				txtBookName.setText(issue.getBookName());
				txtBookEdition.setText(issue.getEdition());
				txtBookPublisher.setText(issue.getPublisher());
				txtBookPrice.setText(String.valueOf(issue.getPrice()));
				txtBookPages.setText(String.valueOf(issue.getPages()));
				txtBookDateOfIssue.setText(issue.getIssueDate().toString());

				txtStudentName.setText(issue.getStudentName());
				txtStudentSurname.setText(issue.getStudentSurname());
				txtStudentFatherName.setText(issue.getFatherName());
				txtStudentCourse.setText(issue.getCourse());
				txtStudentBranch.setText(issue.getBranch());
				txtStudentYear.setText(String.valueOf(issue.getYear()));
				txtStudentSemester.setText(String.valueOf(issue.getSemester()));
			} else {
				JOptionPane.showMessageDialog(this, "No issued book found for this student ID.");
			}
		} catch (NumberFormatException | SQLException e) {
			JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
		}
	}

	private void processReturn(JDateChooser dateChooser) {
		try {
			// Öğrenci ve kitap ID'sini kontrol et
			if (txtStudentId.getText().trim().isEmpty() || txtBookId.getText().trim().isEmpty()) {
				JOptionPane.showMessageDialog(this, "Student ID and Book ID cannot be empty!");
				return;
			}

			int studentId = Integer.parseInt(txtStudentId.getText().trim());
			int bookId = Integer.parseInt(txtBookId.getText().trim());

			// Return nesnesini oluştur ve tüm alanları ata
			Return returnRecord = new Return();
			returnRecord.setStudentId(studentId);
			returnRecord.setStudentName(txtStudentName.getText().trim());
			returnRecord.setStudentSurname(txtStudentSurname.getText().trim());
			returnRecord.setStudentFatherName(txtStudentFatherName.getText().trim());
			returnRecord.setCourse(txtStudentCourse.getText().trim());
			returnRecord.setBranch(txtStudentBranch.getText().trim());
			returnRecord.setYear(Integer.parseInt(txtStudentYear.getText().trim()));
			returnRecord.setSemester(Integer.parseInt(txtStudentSemester.getText().trim()));

			returnRecord.setBookId(bookId);
			returnRecord.setBookName(txtBookName.getText().trim());
			returnRecord.setEdition(txtBookEdition.getText().trim());
			returnRecord.setPublisher(txtBookPublisher.getText().trim());
			returnRecord.setPrice(Double.parseDouble(txtBookPrice.getText().trim()));
			returnRecord.setPages(Integer.parseInt(txtBookPages.getText().trim()));

			// Tarih alanlarını kontrol et
			if (!txtBookDateOfIssue.getText().trim().isEmpty()) {
				returnRecord.setDateOfIssue(java.sql.Date.valueOf(txtBookDateOfIssue.getText().trim()));
			} else {
				returnRecord.setDateOfIssue(null); // Boş ise null ata
			}

			if (dateChooser.getDate() != null) {
				returnRecord.setDateOfReturn(dateChooser.getDate());
			} else {
				JOptionPane.showMessageDialog(this, "Return date cannot be empty!");
				return;
			}

			// Return işlemini gerçekleştirme
			ReturnService returnService = new ReturnService(DatabaseConnection.getConnection());
			returnService.returnBook(studentId, bookId, returnRecord);

			// Başarı mesajı
			JOptionPane.showMessageDialog(this, "Book returned successfully!");
			clearFields();

		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(this, "Invalid number format: " + e.getMessage());
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Unexpected error: " + e.getMessage());
		}
	}

	private void clearFields() {
		txtStudentId.setText("");
		txtStudentName.setText("");
		txtStudentSurname.setText("");
		txtStudentFatherName.setText("");
		txtStudentCourse.setText("");
		txtStudentBranch.setText("");
		txtStudentYear.setText("");
		txtStudentSemester.setText("");
		txtBookId.setText("");
		txtBookName.setText("");
		txtBookEdition.setText("");
		txtBookPublisher.setText("");
		txtBookPrice.setText("");
		txtBookPages.setText("");
		txtBookDateOfIssue.setText("");
	}
}
