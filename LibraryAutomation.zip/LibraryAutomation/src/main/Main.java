package main;

import controller.LoginController;

public class Main {
	public static void main(String[] args) {
		// LoginController'ı başlatıyoruz
		LoginController controller = LoginController.getInstance();
		// LoginFrame gösterilecek
		controller.getLoginFrame().setVisible(true);
	}
}

