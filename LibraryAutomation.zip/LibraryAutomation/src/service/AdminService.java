package service;

import java.sql.SQLException;
import java.util.List;

import dao.AdminDAO;
import model.User;

public class AdminService {
	private AdminDAO adminDAO;

	public AdminService() {
		this.adminDAO = new AdminDAO();
	}

	// Tüm kullanıcıları listele
	public List<User> getAllUsers() throws SQLException {
		return adminDAO.getAllUsers();
	}

	// Username'e göre kullanıcıyı getir
	public User getUserByUsername(String username) throws SQLException {
		return adminDAO.getUserByUsername(username);
	}

	// Kullanıcıyı güncelle
	public void updateUser(User user) throws SQLException {
		adminDAO.updateUser(user);
	}

	public void deleteUser(int userId) throws SQLException {
		adminDAO.deleteUser(userId); // AdminDAO'daki deleteUser metodunu çağır
	}

	public User getUserById(int userId) throws SQLException {
		return adminDAO.getUserById(userId);
	}
}
