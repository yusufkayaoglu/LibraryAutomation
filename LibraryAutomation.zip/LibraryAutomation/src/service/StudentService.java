package service;

import dao.StudentDAO;
import model.Student;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class StudentService {
	private StudentDAO studentDAO;

	public StudentService(Connection connection) {
		this.studentDAO = new StudentDAO(connection);
	}

	// Tüm öğrencileri getir
	public List<Student> getStudents() throws SQLException {
		return studentDAO.getAllStudents();
	}

	// Yeni öğrenci ekleme
	public void addStudent(Student student) throws SQLException {
		studentDAO.addStudent(student);
	}

	// Öğrenci ID'sinin var olup olmadığını kontrol et
	public boolean checkIfIdExists(int id) throws SQLException {
		return studentDAO.isIdExists(id);
	}

	// ID'ye göre öğrenci bul
	public Student findStudentById(int id) throws SQLException {
		return studentDAO.getStudentById(id);
	}

	// Öğrenci güncelleme işlemi
	public void updateStudent(Student student) throws SQLException {
		studentDAO.updateStudent(student);
	}

	public void deleteStudent(int id) throws SQLException {
		studentDAO.deleteStudent(id);
	}

}
