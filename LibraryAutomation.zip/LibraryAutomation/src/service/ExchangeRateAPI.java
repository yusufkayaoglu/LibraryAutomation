package service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class ExchangeRateAPI {

	private static final String EXCHANGE_RATE_API_URL = "https://api.exchangerate-api.com/v4/latest/TRY";

	public static String getExchangeRates() {
		try {
			// API'den döviz kuru verilerini çek
			HttpURLConnection exchangeRateConnection = (HttpURLConnection) new URL(EXCHANGE_RATE_API_URL)
					.openConnection();
			exchangeRateConnection.setRequestMethod("GET");

			BufferedReader exchangeRateIn = new BufferedReader(
					new InputStreamReader(exchangeRateConnection.getInputStream()));
			StringBuilder exchangeRateResponse = new StringBuilder();
			String exchangeRateInputLine;
			while ((exchangeRateInputLine = exchangeRateIn.readLine()) != null) {
				exchangeRateResponse.append(exchangeRateInputLine);
			}
			exchangeRateIn.close();

			JSONObject exchangeRateJson = new JSONObject(exchangeRateResponse.toString());

			// TRY bazlı döviz kurları
			double usdToTryRate = 1 / exchangeRateJson.getJSONObject("rates").getDouble("USD");
			double eurToTryRate = 1 / exchangeRateJson.getJSONObject("rates").getDouble("EUR");
			double gbpToTryRate = 1 / exchangeRateJson.getJSONObject("rates").getDouble("GBP");
			double chfToTryRate = 1 / exchangeRateJson.getJSONObject("rates").getDouble("CHF");

			// HTML formatında döviz kurlarını döndür
			return "<html>" + "<img src='" + ExchangeRateAPI.class.getResource("/icons/usd.png")
					+ "' width='24' height='24'> "
					+ "<span style='color: #000000; font-size: 14px; font-family: Verdana;'><b>USD/TRY:</b> "
					+ String.format("%.2f", usdToTryRate) + " TL</span><br><br>" +

					"<img src='" + ExchangeRateAPI.class.getResource("/icons/eur.png") + "' width='24' height='24'> "
					+ "<span style='color: #000000; font-size: 14px; font-family: Verdana;'><b>EUR/TRY:</b> "
					+ String.format("%.2f", eurToTryRate) + " TL</span><br><br>" +

					"<img src='" + ExchangeRateAPI.class.getResource("/icons/gbp.png") + "' width='24' height='24'> "
					+ "<span style='color: #000000; font-size: 14px; font-family: Verdana;'><b>GBP/TRY:</b> "
					+ String.format("%.2f", gbpToTryRate) + " TL</span><br><br>" +

					"<img src='" + ExchangeRateAPI.class.getResource("/icons/chf.png") + "' width='24' height='24'> "
					+ "<span style='color: #000000; font-size: 14px; font-family: Verdana;'><b>CHF/TRY:</b> "
					+ String.format("%.2f", chfToTryRate) + " TL</span><br><br>" + "</html>";

		} catch (Exception e) {
			e.printStackTrace();
			return "Error fetching data: " + e.getMessage();
		}
	}
}
