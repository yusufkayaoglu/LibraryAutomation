package service;

import java.sql.SQLException;
import java.util.List;

import dao.UserDAO;
import model.Admin;
import model.User;
import model.UserSession;

public class UserService {
	private UserDAO userDAO;

	public UserService() {
		this.userDAO = new UserDAO(); // UserDAO'yu burada başlatıyoruz
	}

	// Kullanıcı girişi
	public User login(String username, String password) throws SQLException {
		User user = userDAO.authenticate(username, password);

		if (user != null) {
			// Kullanıcı rolüne göre nesne oluştur
			if ("admin".equalsIgnoreCase(user.getRole())) {
				Admin admin = new Admin(user.getName(), user.getSurname(), user.getUsername(), user.getEmail(),
						user.getPassword(), user.getSecurityQuestion(), user.getAnswer());
				admin.setId(user.getId()); // ID'yi de admin nesnesine ekleyelim
				UserSession.setCurrentUser(admin); // Admin nesnesini oturuma ata
				return admin;
			} else {
				UserSession.setCurrentUser(user); // User nesnesini oturuma ata
				return user;
			}
		}

		return null; // Giriş başarısız
	}

	// Kullanıcı kaydı
	public void register(String name, String surname, String username, String email, String password,
			String securityQuestion, String answer) throws SQLException {
		User user = new User(name, surname, username, email, password, securityQuestion, answer);

		try {
			userDAO.addUser(user);
		} catch (SQLException e) {
			throw new SQLException("Kullanıcı kaydı sırasında bir hata oluştu: " + e.getMessage());
		}
	}

	// Username ile kullanıcıyı getir
	public User getUserByUsername(String username) throws SQLException {
		return userDAO.findByUsername(username);
	}

	// Kullanıcı bilgilerini güncelle
	public void updateUser(User user) throws SQLException {
		userDAO.updateUser(user);
	}

	// Kullanıcı sil
	public void deleteUser(int userId) throws SQLException {
		userDAO.deleteUser(userId);
	}

}
