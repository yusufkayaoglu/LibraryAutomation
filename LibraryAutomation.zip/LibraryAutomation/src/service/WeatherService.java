package service;

import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.JSONObject;

public class WeatherService {

	private static final String API_KEY = "475a00859e6d8930095b3b5a05de1249";
	private static final String BASE_URL = "http://api.openweathermap.org/data/2.5/weather";

	public static String getWeather(String city) {
		try {
			// API URL
			String urlString = BASE_URL + "?q=" + city + "&appid=" + API_KEY + "&units=metric";

			// Open URL connection
			URL url = new URL(urlString);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");

			// Check response code
			int responseCode = connection.getResponseCode();
			if (responseCode != HttpURLConnection.HTTP_OK) {
				return "<html><span style='color: #FF0000; font-size: 18px;'>Error: Unable to retrieve weather data! ("
						+ responseCode + ")</span></html>";
			}

			// Read the response
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			StringBuilder response = new StringBuilder();
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// Parse the JSON response
			JSONObject myResponse = new JSONObject(response.toString());
			JSONObject main = myResponse.getJSONObject("main");
			JSONObject weather = myResponse.getJSONArray("weather").getJSONObject(0);
			JSONObject wind = myResponse.getJSONObject("wind");

			// Retrieve the data
			String cityName = myResponse.getString("name");
			double temperature = main.getDouble("temp");
			int humidity = main.getInt("humidity");
			String description = weather.getString("description");
			double windSpeed = wind.getDouble("speed");

			// Determine weather icon based on description
			String weatherIcon = getWeatherIcon(description);

			return "<html>" + "<img src='" + WeatherService.class.getResource("/icons/city.png")
					+ "' width='24' height='24'> "
					+ "<span style='color: #1E90FF; font-size: 14px; font-family: Verdana;'>City: " + cityName
					+ "</span><br><br>" + "<img src='" + WeatherService.class.getResource("/icons/temperature.png")
					+ "' width='24' height='24'> "
					+ "<span style='color: #FF6347; font-size: 14px; font-family: Verdana;'>Temperature: " + temperature
					+ "°C</span><br><br>" + "<img src='" + WeatherService.class.getResource("/icons/humidity.png")
					+ "' width='24' height='24'> "
					+ "<span style='color: #32CD32; font-size: 14px; font-family: Verdana;'>Humidity: " + humidity
					+ "%</span><br><br>" + "<img src='" + weatherIcon + "' width='24' height='24'> "
					+ "<span style='color: #FFD700; font-size: 14px; font-family: Verdana;'>Description: " + description
					+ "</span><br><br>" + "<img src='" + WeatherService.class.getResource("/icons/wind.png")
					+ "' width='24' height='24'> "
					+ "<span style='color: #8A2BE2; font-size: 14px; font-family: Verdana;'>Wind Speed: " + windSpeed
					+ " m/s</span><br><br>" + "</html>";

		} catch (Exception e) {
			e.printStackTrace();
			return "<html><span style='color: #FF0000; font-size: 18px;'>Unable to retrieve weather data!</span></html>";
		}
	}

	// Determine the appropriate icon for the weather description
	private static String getWeatherIcon(String description) {
		String basePath = "/icons/";
		if (description.contains("clear")) {
			return WeatherService.class.getResource(basePath + "clear.png").toString();
		} else if (description.contains("rain")) {
			return WeatherService.class.getResource(basePath + "rain.png").toString();
		} else if (description.contains("cloud")) {
			return WeatherService.class.getResource(basePath + "cloud.png").toString();
		} else if (description.contains("snow")) {
			return WeatherService.class.getResource(basePath + "snow.png").toString();
		} else if (description.contains("thunderstorm")) {
			return WeatherService.class.getResource(basePath + "storm.png").toString();
		} else {
			return WeatherService.class.getResource(basePath + "default.png").toString();
		}
	}
}
