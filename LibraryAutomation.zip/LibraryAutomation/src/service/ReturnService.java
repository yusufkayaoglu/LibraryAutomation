package service;

import dao.IssueDAO;
import dao.ReturnDAO;
import model.Return;

import java.sql.Connection;
import java.sql.SQLException;

public class ReturnService {
	private IssueDAO issueDAO;
	private ReturnDAO returnDAO;

	public ReturnService(Connection connection) {
		this.issueDAO = new IssueDAO(connection);
		this.returnDAO = new ReturnDAO(connection);
	}

	public void returnBook(int studentId, int bookId, Return returnRecord) throws SQLException {
		// Ödünç kaydını sil (hem öğrenci ID hem kitap ID'ye göre)
		issueDAO.deleteIssueByStudentIdAndBookId(studentId, bookId);
		// İade kaydını ekle
		returnDAO.insertReturnRecord(returnRecord);
	}
}
