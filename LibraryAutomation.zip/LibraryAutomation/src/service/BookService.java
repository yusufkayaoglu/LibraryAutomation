package service;

import dao.BookDAO;
import model.Book;
import model.Issue;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class BookService {
	private BookDAO bookDAO;

	public BookService(Connection connection) {
		this.bookDAO = new BookDAO(connection);
	}

	// Tüm kitapları getir
	public List<Book> getBooks() throws SQLException {
		return bookDAO.getAllBooks();
	}

	// Yeni kitap ekleme
	public void addBook(Book book) throws SQLException {
		bookDAO.addBook(book);
	}

	public boolean checkIfIdExists(int id) throws SQLException {
		return bookDAO.isIdExists(id);
	}

	// ID'ye göre kitap bul
	public Book findBookById(int id) throws SQLException {
		return bookDAO.getBookById(id);
	}

	// Kitap güncelleme
	public void updateBook(Book book) throws SQLException {
		bookDAO.updateBook(book);
	}

	public void deleteBook(int id) throws SQLException {
		bookDAO.deleteBook(id);
	}

}
