package service;

import java.sql.Connection;
import java.sql.SQLException;

import dao.BookDAO;
import dao.IssueDAO;
import model.Issue;

public class IssueService {

	private IssueDAO issueDAO;

	public IssueService(Connection connection) {
		this.issueDAO = new IssueDAO(connection); // Create an instance of IssueDAO

	}

	public boolean issueBook(Issue issue) throws SQLException {
		return issueDAO.saveIssue(issue);
	}
}
