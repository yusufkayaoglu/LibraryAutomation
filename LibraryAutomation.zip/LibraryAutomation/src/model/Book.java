package model;

import java.math.BigDecimal;

public class Book {
	private int book_Id;
	private String book_Name;
	private String book_Edition;
	private String book_Publisher;
	private double book_Price;
	private int book_Page;
	private String studentId; // Kitap verildiği öğrencinin ID'si
	private String issueDate; // Kitap veriş tarihi

	public Book(int book_Id, String book_Name, String book_Edition, String book_Publisher, double book_Price,
			int book_Page) {
		this.book_Id = book_Id;
		this.book_Name = book_Name;
		this.book_Edition = book_Edition;
		this.book_Publisher = book_Publisher;
		this.book_Price = book_Price;
		this.book_Page = book_Page;

	}

	public int getBook_Id() {
		return book_Id;
	}

	public void setBook_Id(int book_Id) {
		this.book_Id = book_Id;
	}

	public String getBook_Name() {
		return book_Name;
	}

	public void setBook_Name(String book_Name) {
		this.book_Name = book_Name;
	}

	public String getBook_Edition() {
		return book_Edition;
	}

	public void setBook_Edition(String book_Edition) {
		this.book_Edition = book_Edition;
	}

	public String getBook_Publisher() {
		return book_Publisher;
	}

	public void setBook_Publisher(String book_Publisher) {
		this.book_Publisher = book_Publisher;
	}

	public double getBook_Price() {
		return book_Price;
	}

	public void setBook_Price(double book_Price) {
		this.book_Price = book_Price;
	}

	public int getBook_Page() {
		return book_Page;
	}

	public void setBook_Page(int book_Page) {
		this.book_Page = book_Page;
	}

}
