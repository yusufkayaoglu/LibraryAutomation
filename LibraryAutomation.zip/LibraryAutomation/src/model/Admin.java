package model;

public class Admin extends User {

	// Admin sınıfına özel constructor
	public Admin(String name, String surname, String username, String email, String password, String securityQuestion,
			String answer) {
		// User sınıfının constructor'ını çağırıyoruz
		super(name, surname, username, email, password, securityQuestion, answer);
		// Admin için rolü otomatik olarak "Admin" yapıyoruz
		this.setRole("Admin");
	}
}
