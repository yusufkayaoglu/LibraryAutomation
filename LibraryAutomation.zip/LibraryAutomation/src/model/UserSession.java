package model;

public class UserSession {
	private static User currentUser;

	// Kullanıcıyı set etmek (oturum açma)
	public static void setCurrentUser(User user) {
		currentUser = user;
	}

	// Mevcut kullanıcıyı almak
	public static User getCurrentUser() {
		return currentUser;
	}

	// Kullanıcıyı null yapmak (oturum kapatma)
	public static void clearCurrentUser() {
		currentUser = null;
	}

	// Oturum açık mı kontrolü
	public static boolean isUserLoggedIn() {
		return currentUser != null;
	}

	// Mevcut kullanıcı bilgilerini güvenli şekilde almak
	public static String getUserInfo() {
		if (currentUser != null) {
			return "User: " + currentUser.getName() + " (" + currentUser.getUsername() + ")";
		} else {
			return "No user is currently logged in.";
		}
	}
}
