package model;

import java.util.Date;

public class Issue {
	private int bookId;
	private String bookName;
	private String edition;
	private String publisher;
	private double price;
	private int pages;
	private int studentId;
	private String studentName;
	private String studentSurname;
	private String fatherName;
	private String course;
	private String branch;
	private int year;
	private int semester;
	private Date issueDate; // Değiştirildi: int -> Date

	// Constructor
	public Issue(int bookId, String bookName, String edition, String publisher, double price, int pages, int studentId,
			String studentName, String studentSurname, String fatherName, String course, String branch, int year,
			int semester, Date issueDate) { // Değiştirildi: int issueDate -> Date issueDate
		this.bookId = bookId;
		this.bookName = bookName;
		this.edition = edition;
		this.publisher = publisher;
		this.price = price;
		this.pages = pages;
		this.studentId = studentId;
		this.studentName = studentName;
		this.fatherName = fatherName;
		this.course = course;
		this.branch = branch;
		this.year = year;
		this.semester = semester;
		this.issueDate = issueDate;
		this.studentSurname = studentSurname;
	}

	// Getter ve Setter metodları
	public int getBookId() {
		return bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public String getEdition() {
		return edition;
	}

	public String getPublisher() {
		return publisher;
	}

	public double getPrice() {
		return price;
	}

	public int getPages() {
		return pages;
	}

	public int getStudentId() {
		return studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public String getCourse() {
		return course;
	}

	public String getBranch() {
		return branch;
	}

	public int getYear() {
		return year;
	}

	public int getSemester() {
		return semester;
	}

	public Date getIssueDate() { // Güncellenmiş getter
		return issueDate;
	}

	public void setIssueDate(Date issueDate) { // Güncellenmiş setter
		this.issueDate = issueDate;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getStudentSurname() {
		return studentSurname;
	}

	public void setStudentSurname(String studentSurname) {
		this.studentSurname = studentSurname;
	}

}
