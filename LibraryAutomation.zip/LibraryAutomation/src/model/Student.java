package model;

public class Student {
	private int student_Id;
	private String student_Name;
	private String student_Surname;
	private String student_fatherName;
	private String student_Course;
	private String student_Branch;
	private int student_Year;
	private int student_Semester;

	public Student(int student_Id, String student_Name, String student_Surname, String student_fatherName,
			String student_Course, String student_Branch, int student_Year, int student_Semester) {

		this.student_Id = student_Id;
		this.student_Name = student_Name;
		this.student_Surname = student_Surname;
		this.student_fatherName = student_fatherName;
		this.student_Course = student_Course;
		this.student_Branch = student_Branch;
		this.student_Year = student_Year;
		this.student_Semester = student_Semester;
	}

	public int getStudent_Id() {
		return student_Id;
	}

	public void setStudent_Id(int student_Id) {
		this.student_Id = student_Id;
	}

	public String getStudent_Name() {
		return student_Name;
	}

	public void setStudent_Name(String student_Name) {
		this.student_Name = student_Name;
	}

	public String getStudent_fatherName() {
		return student_fatherName;
	}

	public void setStudent_fatherName(String student_fatherName) {
		this.student_fatherName = student_fatherName;
	}

	public String getStudent_Course() {
		return student_Course;
	}

	public void setStudent_Course(String student_Course) {
		this.student_Course = student_Course;
	}

	public String getStudent_Branch() {
		return student_Branch;
	}

	public void setStudent_Branch(String student_Branch) {
		this.student_Branch = student_Branch;
	}

	public int getStudent_Year() {
		return student_Year;
	}

	public void setStudent_Year(int student_Year) {
		this.student_Year = student_Year;
	}

	public int getStudent_Semester() {
		return student_Semester;
	}

	public void setStudent_Semester(int student_Semester) {
		this.student_Semester = student_Semester;
	}

	public String getStudent_Surname() {
		return student_Surname;
	}

	public void setStudent_Surname(String student_Surname) {
		this.student_Surname = student_Surname;
	}

}
